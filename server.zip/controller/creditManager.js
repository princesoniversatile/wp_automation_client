const User = require('../model/user');

exports.getCreditLimit = async (req, res) => {
  try {
    const { emailId } = req.query;
    const user = await User.findOne({ emailId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    const creditLimit = user.creditLimit;
    const messageCount = user.messageCount;
    res.json({ creditLimit, messageCount });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.updateCreditLimit = async (req, res) => {
  try {
    const { emailId, newCreditLimit } = req.body;
    const user = await User.findOne({ emailId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    user.creditLimit = newCreditLimit;
    user.messageCount = 0;
    await user.save();
    res.json({ message: 'Credit limit updated successfully' });
  } catch (error) {
    res.status(500).json({ message: '500 see error', error: error.message });
  }
};


exports.addCreditDebitLimit = async (req, res) => {
  try {
    const { emailId, amount, type } = req.body;
    const user = await User.findOne({ emailId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    if (type === 'credit') {
      user.creditLimit += amount;
    } else if (type === 'debit') {
      user.creditLimit -= amount;
    } else {
      return res.status(400).json({ message: 'Invalid type' });
    }
    user.messageCount = 0;
    await user.save();
    res.json({ message: `${type} balance updated successfully` });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.deductMessageBalance = async (req, res) => {
  try {
    const { emailId, messageCount } = req.body;
    const user = await User.findOne({ emailId });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    if (user.creditLimit < messageCount) {
      return res.status(400).json({ message: 'Insufficient message balance' });
    }
    user.creditLimit -= messageCount;
    await user.save();
    res.json({ message: 'Message balance deducted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};



