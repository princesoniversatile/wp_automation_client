const User = require('../model/user');

// Login controller
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const user = await User.findOne({ emailId: email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Compare passwords (simple comparison, not secure)
    if (password !== user.password) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Send user data
    res.status(200).json({
      success: true,
      user: {
        id: user._id,
        username: user.username,
        email: user.emailId,
        type: user.type
      },
      message: 'Login successful'
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Change password
exports.changePassword = async (req, res) => {
  try {
    const { email, currentPassword, newPassword } = req.body;

    // Find user by email
    const user = await User.findOne({ emailId: email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Verify current password
    if (currentPassword !== user.password) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password changed successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.emailId
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};


// Get user details
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find()
    // .select('-password');
    if (users.length === 0) {
      return res.status(404).json({ message: 'No users found' });
    }
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new user
exports.createUser = async (req, res) => {
  try {
    const { companyName, contactPerson, address, city, state, mobileNo, whatsappNo, creditLimit, username, password, emailId } = req.body;

    // Check if user already exists
    let user = await User.findOne({ $or: [{ companyName }, { contactPerson }] });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create new user (storing password as plain text, not secure)
    user = new User({
      companyName,
      contactPerson,
      address,
      city,
      state,
      mobileNo,
      whatsappNo,
      creditLimit,
      username,
      password,
      emailId
    });

    await user.save();

    res.status(201).json({
      message: 'User created successfully',
      user: {
        username: user.username,
        email: user.emailId,
        id: user._id,
        password: user.password
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update user
exports.updateUser = async (req, res) => {
  try {
    const { id, ...updateFields } = req.body;

    // Check if user exists
    let user = await User.findById(id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update user
    Object.keys(updateFields).forEach(field => {
      user[field] = updateFields[field];
    });

    await user.save();

    res.status(200).json({ message: 'User updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};



exports.retrievePassword = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ emailId: email });
    if (!user) {
      return res.status(404).json({ message: 'invalid user 404' });
    }
    res.json({ password: user.password });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
