const fs = require('fs')
const express = require('express')
const venom = require('venom-bot')
const cors = require('cors')
const app = express()
const path = require('path')
const multer = require('multer');
const mongoose = require('mongoose');
const Message = require('./model/messageHistory'); // Add this import at the top of the file
const { login, changePassword, getAllUsers,createUser,retrievePassword } = require('./controller/Login');
const { getCreditLimit, updateCreditLimit, addCreditDebitLimit, deductMessageBalance } = require('./controller/creditManager');
const User = require('./model/user');

let apiLimits = {
  maxMessagesPerMinute: 2, // Default limit
  messageCount: 0
}


// const Chat = require('./controllers/Chat')
// app.use(express.urlencoded({ extended: true }))
// app.use(express.json())

app.use(express.json({ limit: '10mb' })); // 10mb ka limit set kar diya
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Serve static files from the 'public' directory
const port = process.env.PORT || 4001
app.use(cors())
let isQrScanned = false
app.use(express.static(path.join(__dirname, 'public')))

function saveQRImage (base64Qr) {
  const matches = base64Qr.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/)

  if (matches.length !== 3) {
    throw new Error('Invalid input string')
  }

  const response = {
    type: matches[1],
    data: Buffer.from(matches[2], 'base64')
  }

  // Write the image data to a PNG file named 'out.png'
  fs.writeFile('out.png', response.data, 'base64', function (err) {
    if (err != null) {
      console.log(err)
    } else {
      console.log('QR code saved as out.png')
    }
  })
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
})
// API endpoint to serve the 'out.png' file
app.get('/qrimage', (req, res) => {
  const imagePath = `${__dirname}/out.png`

  fs.readFile(imagePath, (err, data) => {
    if (err) {
      console.error(err)
      res.status(500).send('Internal Server Error')
    } else {
      res.writeHead(200, { 'Content-Type': 'image/png' })
      res.end(data)
    }
  })
})

// Endpoint to set the connection status after scanning the QR code
app.get('/check-status', (req, res) => {
  res.json({ connected: isQrScanned })
})

// Endpoint to handle the QR code scan event
app.get('/qr-scanned', (req, res) => {
  isQrScanned = true
  res.send('QR code scanned successfully!')
})

//our pre-Build Functionality
let sessionLogin = '0'
let clientInstance = null
// function dateLog (text) {
//   console.log(new Date(), ' - ', text)
// }

function dateLog (message) {
  const timestamp = new Date().toLocaleString()
  console.log(`[${timestamp}] ${message}`)
}

const home = 'home-account'

// Endpoint to generate and retrieve the QR code

async function startClient () {
  dateLog('Starting bot...')
  try {
    const client = await venom.create(
      { session: home,headless: false },
      base64Qr => {
        // Write the QR code as a PNG file
        saveQRImage(base64Qr)
      },
      undefined,
      { logQR: true        
      }, // Ensure logQR is set to true to get ASCII QR
      
    ) // Replace 'session-name' with your actual session

    clientInstance = client
    dateLog('Bot started.')
    // Your message handling logic and other functionalities here...
    client.onMessage(async message => {
      // Handle incoming messages here
      //handlereply(client, message,lastCommand)
      // dateLog(`Received message with full details: ${JSON.stringify(message, null, 2)}`);
      dateLog(`Received message from ${message.from}: ${message.body}`)
      // If it's a group message, log the group name
      const groupName = message.isGroupMsg
        ? message.groupInfo?.name || 'N/A'
        : 'Not a group message'

      // Log details including the group name
      dateLog(`Additional Details:
      From: ${message.from}
      Body: ${message.body}
      Sender Name: ${message.sender.pushname}
      Is Group Message: ${message.isGroupMsg}
      Group Name: ${groupName}
      Chat ID: ${message.chat?.id?._serialized || 'N/A'}
      Is Media: ${message.isMedia}
      Message Type: ${message.type}
    `)

      // Handle messages as needed...

      //code begins here
      try {
        const content =
          typeof message.body === 'string'
            ? message.body.toLowerCase()
            : message.body

        if (content === 'hi' && message.isGroupMsg === false) {
          await client.startTyping(message.from)

          await client.sendText(message.from, `welcome`)
          await client.startTyping(message.from)

          await client.sendText(message.from, afterIntroText + commandsInfo)
          if (sessionLogin === '1') {
            setTimeout(async () => {
              await client.sendText(
                message.from,
                `*Session Expired* For Restart Again Type 'hi'`
              )
            }, 28 * 60 * 1000)
          }
        } else if (content === '!qr') {
          await client.sendText(message.from, `this is working`)
        }
      } catch (error) {
        console.error('Error occurred:', error)
      }
    })
  } catch (error) {
    dateLog('Error occurred during bot start:', error)
  }
}

function restartClient () {
  dateLog('Restarting bot...')

  try {
    if (clientInstance) {
      sessionLogin = '0'
      clientInstance.close()
      clientInstance = null
    }
    dateLog('Bot closed. Restarting...')
    startClient()
  } catch (error) {
    dateLog('Error occurred during bot restart:', error)
  }
}

function setupRestartTimer () {
  // Set a restart timer for 20 minutes
  setInterval(restartClient, 29 * 60 * 1000) // Restart every 15 minutes
}

// Start the bot initially
startClient()

// Set up restart timer
// setupRestartTimer()

module.exports = {
  clientInstance
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Where file will be saved
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique file name
  },
});

const upload = multer({ storage: storage });

app.use('/welcome', (req, res) => {
  res.status(404).send('<h1>Welcome To Este Hydrolo Server !!</h1>')
})

app.get('/send-groups', async (req, res) => {
  // const { message, groupName } = req.query

  // if (!message || !groupName) {
  //   return res
  //     .status(400)
  //     .json({ error: 'Both message and groupName parameters are required' })
  // }

  try {
    console.log(clientInstance)
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    // const chats =  await clientInstance.getAllMessagesInChat('000000000000@c.us')()
    // const chatsAllNew = getAllChatsNewMsg();
    const chats = await clientInstance.getGroupMembers('120363315019986622@g.us');

    // const chats = await clientInstance.getAllChatsGroups()

    return res.json({ data: chats })
  } catch (error) {
    console.error('Error:', error)
    res.status(500).json({ error: error.message })
  }
})


app.get('/getMembers/:groupId', async (req, res) => {
  const groupId = req.params.groupId;

  // Validate if groupId is provided
  if (!groupId) {
    return res.status(400).json({ error: 'Group ID is required' });
  }

  try {
    // console.log(clientInstance);
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' });
    }

    const chats = await clientInstance.getGroupMembers(groupId+'@g.us');

    // Check if group is found or not
    if (chats.erro && chats.text === 'Group not found') {
      return res.status(404).json({ error: 'Invalid group ID: Group not found' });
    }

    // Map through chats to create the desired response structure
    const formattedMembers = chats.map((member) => ({
      memberName: member.pushname || 'Unknown',
      memberNumber: member.id.user,
    }));

    return res.json({ members: formattedMembers });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});


app.get('/contacts', async (req, res) => {
  // const { message, groupName } = req.query

  // if (!message || !groupName) {
  //   return res
  //     .status(400)
  //     .json({ error: 'Both message and groupName parameters are required' })
  // }

  try {

    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }


    const contacts = await clientInstance.getAllChatsContacts();

    const response = contacts.map(contact => {
      return {
        profileLink: contact.contact.profilePicThumbObj?.eurl || '', 
        Name: contact.contact.name || 'Unknown', 
        MobileNumb: contact.contact.id._serialized.split('@')[0] // '@g.us' 
      };
    });

    // Final response bhej denge
    return res.json({ data: response });

    // return res.json({ data: contacts })
  } catch (error) {
    console.error('Error:', error)
    res.status(500).json({ error: error.message })
  }
})

app.get('/groupData', async (req, res) => {
  try {
    // console.log(clientInstance);
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' });
    }

    // Sab groups ka data le lenge
    const chats = await clientInstance.getAllChatsGroups();

    // Required format me response convert karenge
    const response = chats.map(chat => {
      return {
        profileLink: chat.contact.profilePicThumbObj?.eurl || '', 
        groupName: chat.contact.name || 'Unknown', 
        groupId: chat.contact.id._serialized.split('@')[0] // '@g.us' 
      };
    });

    // Final response bhej denge
    return res.json({ data: response });
  } catch (error) {
    console.error('Error:', error);
    return res.status(500).json({ error: error.message });
  }
});


app.get('/send-group', async (req, res) => {
  const { message, groupName } = req.query

  // Validate if message and groupName are provided
  if (!message || !groupName) {
    return res
      .status(400)
      .json({ error: 'Both message and groupName parameters are required' })
  }

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    // Get all group chats
    const chats = await clientInstance.getAllChatsGroups()

    // Find the group with the matching name
    const groupChat = chats.find(chat => chat.contact.name === groupName)

    if (!groupChat) {
      return res
        .status(404)
        .json({ error: `Group with name "${groupName}" not found` })
    }

    // Extract the group ID
    const chatId = groupChat.contact.id._serialized

    // Send the message to the group
    await clientInstance.sendText(chatId, message)

    // Log the sent message details including group name
    dateLog(`Sent message "${message}" to Group: ${groupName} (${chatId})`)

    // Include group name and ID in the response
    res.json({
      success: true,
      groupName: groupChat.contact.name,
      groupId: chatId
    })
  } catch (error) {
    console.error('Error:', error)
    res.status(500).json({ error: error.message })
  }
})



app.get('/send', async (req, res) => {
  const { message, number,emailId } = req.query

  if (!message || !number || !emailId) {
    return res
      .status(400)
      .json({ error: 'Message, number and emailId parameters are required' })
  }

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    

    const user = await User.findOne({ emailId: emailId });

    if(!user){
      return res.status(404).json({ error: 'User not found' })
    }


    
    if (user.messageCount >= user.creditLimit) {
      return res.send({ error: 'Message limit exceeded' })
    }

    await clientInstance.sendText(`${number}@c.us`, message)


    user.messageCount++
    user.creditLimit -= user.messageCount;

    await user.save();

    dateLog(`Sent "${message}" to ${number}`)
    res.json({ success: true })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: error.text })
  }
})
// app.get('/send', async (req, res) => {
//   const { message, number } = req.query

//   if (!message || !number) {
//     return res
//       .status(400)
//       .json({ error: 'Message and number parameters are required' })
//   }

//   try {
//     if (!clientInstance) {
//       return res.status(500).json({ error: 'WhatsApp session not started' })
//     }

    

//     if (apiLimits.messageCount >= apiLimits.maxMessagesPerMinute) {
//       return res.status(429).json({ error: 'Message limit exceeded' })
//     }

//     await clientInstance.sendText(`${number}@c.us`, message)
//     apiLimits.messageCount++
//     dateLog(`Sent "${message}" to ${number}`)
//     res.json({ success: true })
//   } catch (error) {
//     console.error(error)
//     res.status(500).json({ error: error.text })
//   }
// })

// app.get('/sendFile', upload.single('file'), async (req, res) => {
//   const file = req.file; // Uploaded file

//   const { link, number, fileName, caption = '' } = req.query;

//   // Check if required parameters are provided
//   if (!link || !number || !fileName) {
//     return res
//       .status(400)
//       .json({ error: 'Link, number, and fileName parameters are required' });
//   }

//   // Validate file format
//   const validFormats = ['.pdf', '.png', '.jpg', '.jpeg', '.webp', '.xls', '.xlsx'];
//   const fileExtension = link.substring(link.lastIndexOf('.')).toLowerCase();
  
//   if (!validFormats.includes(fileExtension)) {
//     return res
//       .status(400)
//       .json({ error: 'Invalid file format. Allowed formats are .pdf, .png, .jpg, .jpeg, .webp, .xls, .xlsx' });
//   }

//   try {
//     // Checking if WhatsApp client instance is initialized
//     if (!clientInstance) {
//       return res.status(500).json({ error: 'WhatsApp session not started' });
//     }

//     // Send file to WhatsApp number
//     await clientInstance.sendFile(
//       number + '@c.us',  // WhatsApp number to send the file
//       link,              // File URL
//       fileName,          // File name to display
//       caption            // Caption with the file (optional)
//     );

//     // Logging the message sent
//     dateLog(`Sent file "${fileName}" with caption "${caption}" to ${number}`);

//     // Sending success response
//     res.json({ success: true });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: error.message || 'Failed to send file' });
//   }
// });


app.post('/sendImage', async (req, res) => {
  const { base64Image, number, fileName, caption = '' } = req.body;

  // Check if required parameters are provided
  if (!base64Image || !number || !fileName) {
    return res.status(400).json({
      error: 'base64Image, number, and fileName parameters are required',
    });
  }

  try {
    // Check if WhatsApp client instance is initialized
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' });
    }

    // Send base64 image to WhatsApp number
    await clientInstance.sendImageFromBase64(
      number + '@c.us', // WhatsApp number
      base64Image, // Base64 encoded image
      fileName, // File name to display
      caption // Caption with the file (optional)
    );

    // Logging the message sent
    console.log(`Sent file "${fileName}" with caption "${caption}" to ${number}`);

    // Respond with success
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Failed to send file' });
  }
});



app.get('/send-link', async (req, res) => {
  const { link, number, fileName, caption = '' } = req.query;

  // Check if required parameters are provided
  if (!link || !number || !fileName) {
    return res
      .status(400)
      .json({ error: 'Link, number, and fileName parameters are required' });
  }

  // Validate file format
  const validFormats = ['.pdf', '.png', '.jpg', '.jpeg', '.webp', '.xls', '.xlsx'];
  const fileExtension = link.substring(link.lastIndexOf('.')).toLowerCase();
  
  if (!validFormats.includes(fileExtension)) {
    return res
      .status(400)
      .json({ error: 'Invalid file format. Allowed formats are .pdf, .png, .jpg, .jpeg, .webp, .xls, .xlsx' });
  }

  try {
    // Checking if WhatsApp client instance is initialized
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' });
    }

    // Send file to WhatsApp number
    await clientInstance.sendFile(
      number + '@c.us',  // WhatsApp number to send the file
      link,              // File URL
      fileName,          // File name to display
      caption            // Caption with the file (optional)
    );

    // Logging the message sent
    dateLog(`Sent file "${fileName}" with caption "${caption}" to ${number}`);

    // Sending success response
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Failed to send file' });
  }
});




app.post('/send', async (req, res) => {
  const { message, number } = req.body

  if (!message || !number) {
    return res
      .status(400)
      .json({ error: 'Message and number parameters are required' })
  }

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    await clientInstance.sendText(number + '@c.us', message)
    dateLog(`Sent "${message}" to ${number}`)
    res.json({ success: true })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: error.text })
  }
})

app.get('/creategrp', async (req, res) => {
  // const { message, number } = req.body;

  // if (!message || !number) {
  //   return res.status(400).json({ error: 'Message and number parameters are required' });
  // }

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    await clientInstance.createGroup('New Group', [
      'number@c.us',
      'number@c.us'
      // '222222222222@c.us'
    ])
    // await clientInstance.sendText(number + '@c.us', message);
    // await clientInstance.sendText(number + '@c.us', message);
    // dateLog(`Sent "${message}" to ${number}`);
    res.json({ success: true, Data: 'Group Created' })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: error.text })
  }
})

app.get('/create-group', async (req, res) => {
  const { groupName, members } = req.query // groupName aur members ko query params se le

  // Validate inputs
  if (!groupName || !members) {
    return res
      .status(400)
      .json({ error: 'Group name and members are required' })
  }

  // Validate and parse members into an array, add '@c.us' suffix, and check if each number is 10 digits
  const membersArray = members.split(',').map(number => number.trim())
  const isValid = membersArray.every(number => /^\d{10}$/.test(number)) // Check for 10-digit numbers

  if (!isValid) {
    return res
      .status(400)
      .json({ error: 'All members must be 10-digit numbers' })
  }

  const membersWithSuffix = membersArray.map(number => `${number}@c.us`)

  if (membersWithSuffix.length === 0) {
    return res.status(400).json({ error: 'Members list cannot be empty' })
  }

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    // Create group
    // const group = await clientInstance.createGroup(groupName, membersWithSuffix);
    const group = await clientInstance.createGroup(groupName, '7976892266@c.us')

    // Log and send success response
    dateLog(
      `Group created: ${groupName} with members: ${membersWithSuffix.join(
        ', '
      )}`
    )
    res.json({ success: true, groupId: group.id._serialized })
  } catch (error) {
    console.error('Error creating group:', error)
    res.status(500).json({ error: error.message })
  }
})

app.get('/test-create-group', async (req, res) => {
  // Static data for testing
  const groupName = 'Test Group'
  const members = ['7665963276@c.us', ' 9256502276@c.us']

  try {
    if (!clientInstance) {
      return res.status(500).json({ error: 'WhatsApp session not started' })
    }

    // Create group with static data
    const group = await clientInstance.createGroup(groupName, members)

    // Log and send success response
    dateLog(`Group created: ${groupName} with members: ${members.join(', ')}`)
    res.json({ success: true, groupId: group.id._serialized })
  } catch (error) {
    console.error('Error creating group:', error)
    res.status(500).json({ error: error.message })
  }
})

mongoose.connect('mongodb+srv://verstechprince:verstechprince@cluster0.kttxx2i.mongodb.net/whatsapp_messages')
.then(() => {
  console.log('Connected to MongoDB');
})
.catch(err => {
  console.error('Failed to connect to MongoDB', err);
});

app.post('/saveMessage', async (req, res) => {
  try {
    const newMessage = new Message(req.body);
    await newMessage.save();
    res.json({ success: true, message: 'Message saved to database' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});


// app.get('/getMessageHistory', async (req, res) => {
//   try {
//     const messages = await Message.find().sort({ createdAt: -1 });
//     res.json({ success: true, messages });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// });

// app.post('/saveMessage', async (req, res) => {
//   try {
//     const { campaignName, date, time, message, recipient, type, status } = req.body;

//     // Naya message banate hain campaign ke saath
//     const newMessage = new Message({
//       campaignName,
//       date,
//       time,
//       message,
//       recipient,
//       type,
//       status,
//     });

//     await newMessage.save();
//     res.json({ success: true, message: 'Message saved to database' });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// });

// app.get('/getMessageHistory', async (req, res) => {
//   try {
//     // Saare messages nikal rahe hain, latest pehle aayenge:
//     const messages = await Message.find().sort({ createdAt: -1 });
//     res.json({ success: true, messages });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// });

app.get('/getMessageHistory', async (req, res) => {
  try {
    // Saare messages nikal rahe hain:
    const messages = await Message.find().sort({ createdAt: -1 });

    // Campaign-wise grouping kar rahe hain:
    const groupedMessages = messages.reduce((acc, message) => {
      const campaign = message.campaignName || 'Uncategorized'; // Default 'Uncategorized' agar campaignName missing ho
      if (!acc[campaign]) {
        acc[campaign] = [];
      }
      acc[campaign].push(message);
      return acc;
    }, {});

    res.json({ success: true, messages: groupedMessages });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});


app.get('/getMessageHistoryFiltered', async (req, res) => {
  try {
    const { campaignName } = req.query;
    const filter = {};

    if (campaignName) {
      filter.campaignName = campaignName;
    }

    const messages = await Message.find(filter).sort({ createdAt: -1 });
    res.json({ success: true, messages });``
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/getTotalCampaign', async (req, res) => {
  try {
    // Aggregation ka use karke campaign-wise count kar rahe hain:
    const totalCampaignsData = await Message.aggregate([
      {
        $group: {
          _id: "$campaignName", // campaignName ke basis pe grouping
          totalMessages: { $count: {} } // har campaign mein message count kar rahe hain
        }
      }
    ]);

    // Response structure change kar rahe hain taaki readable ho:
    const campaigns = totalCampaignsData.map(campaign => ({
      campaignName: campaign._id || 'Uncategorized', // Agar campaignName nahi hai toh 'Uncategorized'
      totalMessages: campaign.totalMessages
    }));

    res.json({ 
      success: true, 
      totalCampaigns: campaigns.length, // Total campaigns count
      campaigns: campaigns 
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});





const setApiLimit = (req, res) => {
  const { maxMessagesPerMinute } = req.body
  if (!maxMessagesPerMinute || isNaN(maxMessagesPerMinute)) {
    return res.status(400).json({ error: 'Invalid limit value' })
  }
  apiLimits.maxMessagesPerMinute = parseInt(maxMessagesPerMinute, 10)
  apiLimits.messageCount = 0 // Reset message count when limit is updated
  res.json({ success: true, newLimit: apiLimits.maxMessagesPerMinute })
}

// New endpoint to get current API limit
const getApiLimit = (req, res) => {
  res.json({
    maxMessagesPerMinute: apiLimits.maxMessagesPerMinute,
    messageCount: apiLimits.messageCount
  })
}

const checkStatus = (req, res) => {
  res.json({
    connected:
      clientInstance && clientInstance.spinStatus
        ? clientInstance.spinStatus.previousText
        : false
  })
}


app.get('/dashboard', async (req, res) => {
  try {
    // Available message balance calculation
    const availableBalance = Math.max(0, apiLimits.maxMessagesPerMinute - apiLimits.messageCount);

    // Group campaigns and count messages
    const campaignData = await Message.aggregate([
      {
        $group: {
          _id: "$campaignName",
          totalMessages: { $count: {} }
        }
      }
    ]);

    // Format campaigns data for response
    const campaigns = campaignData.map(campaign => ({
      campaignName: campaign._id || 'Uncategorized',
      totalMessages: campaign.totalMessages
    }));

    const totalCampaignsCount = campaigns.length;

    // Today's campaigns count
    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayCampaignsCount = await Message.countDocuments({ createdAt: { $gte: startOfToday } });

    // Total sent messages count
    const totalSentMessagesCount = campaigns.reduce((sum, campaign) => sum + campaign.totalMessages, 0);

    // Response structure
    res.json({
      success: true,
      statistics: {
        availableMessageBalance: availableBalance,
        totalCampaigns: totalCampaignsCount,
        todayCampaigns: todayCampaignsCount,
        totalSentMessages: totalSentMessagesCount,
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/getAllUsers', getAllUsers)
app.post('/change-password', changePassword)
app.post('/login', login)
app.post('/register', createUser)
app.post('/retrievePassword', retrievePassword)
app.post('/setApiLimit', setApiLimit)
app.get('/getApiLimit', getApiLimit)
app.get('/check-status', checkStatus)



app.get('/getCreditLimit', getCreditLimit);
app.post('/updateCreditLimit', updateCreditLimit);


app.post('/updateBalance', addCreditDebitLimit);
app.post('/deductMessageBalance', deductMessageBalance);

// Express server
app.listen(port, () => {
  dateLog(`Server is running on port ${port}`)
})

