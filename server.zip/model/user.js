const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  companyName: {
    type: String,
    unique: true,
    trim: true
  },
  contactPerson: {
    type: String,
    trim: true
  },
  address: {
    type: String,
    trim: true
  },
  city: {
    type: String,
    trim: true
  },
  state: {
    type: String,
    trim: true
  },
  mobileNo: {
    type: String,
    trim: true
  },
  whatsappNo: {
    type: String,
    // required: true,
    trim: true
  },
  creditLimit: {
    type: Number,
    // required: true,
    default: 0
  },
  messageCount: {
    type: Number,
    default: 0
  },

  username: {
    type: String,
    // required: true,
    unique: true,
    trim: true
  },
  password: {
    type: String,
    // required: true
  },
  emailId: {
    type: String,
    // required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  type: {
    type: String,
    enum: ['admin', 'superuser'],
    default: 'admin'
  }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
