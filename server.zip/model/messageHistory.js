const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  campaignName: String,  // Campaign ka naam yaha store hoga
  date: String,
  time: String,
  message: String,
  recipient: String,
  type: String,
  status: String,
  email: String,
}, { timestamps: true });

module.exports = mongoose.model('Message', messageSchema);
