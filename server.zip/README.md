# estehydroloBot
In this bot we have designed the bot according the configuration shares the links from company.

http://localhost:4001/send-group?message=hello%20group&groupName=A

  "venom-bot": "github:orkestral/venom" 
