import React, { useEffect } from 'react';
import { ChakraProvider } from '@chakra-ui/react';
import { HashRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import AppTour from './components/AppTour';
import Login from './pages/Login';
import Forgot from './pages/Forgot';
import MessageLimit from './pages/MessageLimit';

const AppRoutes = () => {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  const user = JSON.parse(localStorage.getItem('user'));
  const isSuperUser = user?.type === 'superuser';
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/login');
    }
  }, [isLoggedIn, navigate]);

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Dashboard />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/forgot" element={<Forgot />} />
      <Route path="/tour" element={<AppTour />} />
      {isSuperUser && <Route path="/setlimit" element={<MessageLimit />} />}
    </Routes>
  );
};

const App = () => (
  <ChakraProvider>
    <Router>
      <AppRoutes />
    </Router>
  </ChakraProvider>
);

export default App;
