import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Async thunk for fetching credit limit
export const fetchCreditLimit = createAsyncThunk(
  'creditLimit/fetchCreditLimit',
  async (emailId, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_API_URL}/getCreditLimit`, {
        params: { emailId },
      });
      return response.data.creditLimit;
    } catch (error) {
      // Handle error properly
      return rejectWithValue(error.response.data.message);
    }
  }
);

export const updateCreditLimit = createAsyncThunk(
  'creditLimit/updateCreditLimit',
  async ({ emailId, newCreditLimit }, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_API_URL}/updateCreditLimit`, {
        emailId,
        newCreditLimit,
      });
      return response.data.message;
    } catch (error) {
      return rejectWithValue(error.response.data.message);
    }
  }
);

const creditLimitSlice = createSlice({
  name: 'creditLimit',
  initialState: {
    creditLimit: null,
    loading: false,
    error: null,
  },
  reducers: {
    resetCreditLimit: (state) => {
      state.creditLimit = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCreditLimit.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCreditLimit.fulfilled, (state, action) => {
        state.loading = false;
        state.creditLimit = action.payload;
      })
      .addCase(fetchCreditLimit.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });

    builder
      .addCase(updateCreditLimit.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateCreditLimit.fulfilled, (state, action) => {
        state.loading = false;
        state.creditLimit = action.payload;
      })
      .addCase(updateCreditLimit.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { resetCreditLimit} = creditLimitSlice.actions;

export default creditLimitSlice.reducer;

