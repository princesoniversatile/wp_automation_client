import { configureStore } from '@reduxjs/toolkit';
// import messageLimitsReducer from './messageLimitsSlice';
// import groupManagerReducer from './groupManagerSlice';
// import dashboardReducer from './dashboardSlice';
import {fetchCreditLimit, updateCreditLimit} from './creditLimitSlice';

const store = configureStore({
  reducer: {
    // messageLimits: messageLimitsReducer,
    // groupManager: groupManagerReducer,
    // dashboard: dashboardReducer,
    fetchCreditLimit: fetchCreditLimit,
    updateCreditLimit: updateCreditLimit,
  },
});

export default store;
