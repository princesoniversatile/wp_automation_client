import React, { useState, useEffect } from 'react';
import {
  Box,
  VStack,
  Heading,
  Text,
  Progress,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  useColorModeValue,
  Button,
  HStack,
} from '@chakra-ui/react';
import axios from 'axios';

const MessageLimits = () => {
  const [totalLimit, setTotalLimit] = useState(0);
  const [usedLimit, setUsedLimit] = useState(0);
  const [remainingLimit, setRemainingLimit] = useState(0);
  const [percentageUsed, setPercentageUsed] = useState(0);
  const [currentLimit, setCurrentLimit] = useState(0);

  const bgColor = useColorModeValue('white', 'gray.800');
  const textColor = useColorModeValue('gray.600', 'gray.200');
  const headingColor = useColorModeValue('gray.700', 'white');

  // const fetchLimits = async () => {
  //   const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getApiLimit`);
  //   setTotalLimit(response.data.maxMessagesPerMinute);
  //   setUsedLimit(response.data.messageCount);
  //   setRemainingLimit(response.data.maxMessagesPerMinute - response.data.messageCount);
  //   setPercentageUsed((response.data.messageCount / response.data.maxMessagesPerMinute) * 100);
  // };

  

  const user = JSON.parse(localStorage.getItem('user'))

  const fetchCurrentLimit = async () => {
    try {
      // const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getCreditLimit?emailId=${getEmailById(selectedUser)}`);
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getCreditLimit?emailId=${user.email}`);
      setCurrentLimit(response.data);
      setTotalLimit(response.data.creditLimit);
      setUsedLimit(response.data.messageCount);
      setPercentageUsed((response.data.messageCount / response.data.creditLimit) * 100);
    } catch (error) {
      console.error('Error fetching current limit:', error);
      toast({
        title: 'Error fetching current limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };


  useEffect(() => {
    fetchCurrentLimit();
    // fetchLimits();
  }, []);




  return (
    <Box
      bg={bgColor}
      p={6}
      borderRadius="lg"
      boxShadow="xl"
      maxWidth="600px"
      margin="auto"
    >
      <VStack spacing={6} align="stretch">
        <HStack justifyContent="space-between" align="center">
          <Heading size="lg" color={headingColor}>
            Credit Balance
          </Heading>
          <Button onClick={fetchCurrentLimit}>Refresh</Button>
        </HStack>
        
        <Box>
          <Text fontSize="md" color={textColor} mb={2}>
            Usage Overview
          </Text>
          <Progress
            value={percentageUsed}
            size="lg"
            colorScheme={percentageUsed > 80 ? "red" : "green"}
            borderRadius="full"
          />
        </Box>

        <Stat>
          <StatLabel color={textColor}>Current Limit</StatLabel>
          <StatNumber color={headingColor}>{totalLimit}</StatNumber>
          <StatHelpText color={textColor}>Total available messages</StatHelpText>
        </Stat>

        <Stat>
          <StatLabel color={textColor}>Used</StatLabel>
          <StatNumber color={headingColor}>{usedLimit}</StatNumber>
          <StatHelpText color={textColor}>Messages sent</StatHelpText>
        </Stat>

        {/* <Stat>
          <StatLabel color={textColor}>Remaining</StatLabel>
          <StatNumber color={headingColor}>{remainingLimit}</StatNumber>
          <StatHelpText color={textColor}>Messages available</StatHelpText>
        </Stat> */}
      </VStack>
    </Box>
  );
};

export default MessageLimits;
