import { Box, Button, HStack, VStack, Text, Image, Spinner, Avatar } from "@chakra-ui/react";
import { useState, useEffect } from "react";
import Joyride from 'react-joyride';  // Importing Joyride

const GroupManager = () => {
  const [groups, setGroups] = useState([]); // Groups data
  const [selectedGroup, setSelectedGroup] = useState(null); // Selected group ID
  const [groupMembers, setGroupMembers] = useState([]); // Group members data
  const [isLoading, setIsLoading] = useState(false); // Loading state
  const [runTour, setRunTour] = useState(true); // State to control Joyride

  // Fetch group data
  const fetchGroups = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://192.168.29.100:4001/groupData');
      const { data } = await response.json(); // Response structure has 'data' key
      setGroups(data); // Set the fetched groups
    } catch (error) {
      console.error("Error fetching groups:", error);
    }
    setIsLoading(false);
  };

  // Fetch group members
  const fetchGroupMembers = async (groupId) => {
    setIsLoading(true);
    try {
      const response = await fetch(`http://192.168.29.100:4001/getMembers/${groupId}`);
      const { members } = await response.json(); // Response structure has 'members' key
      setGroupMembers(members); // Set the fetched members
      setSelectedGroup(groupId); // Set the selected group ID
    } catch (error) {
      console.error("Error fetching group members:", error);
    }
    setIsLoading(false);
  };

  // Steps for Joyride
  const steps = [
    {
      target: '.fetch-groups-button', // Target for the button
      content: 'Click here to fetch the groups!',
    },
    {
      target: '.group-item', // Target for the group items
      content: 'Here are your groups. Click on one to see members! Each group shows the number of participants.',
    },
    {
      target: '.group-members', // Target for group members section
      content: 'This section shows the members of the selected group.',
    },
  ];

  useEffect(() => {
    fetchGroups(); // Automatically fetch groups on component mount
  }, []);

  return (
    <Box borderWidth={1} borderRadius="lg" p={5} width="100%" boxShadow="md">
      <Text fontSize="xl" fontWeight="bold" mb={4}>Manage WhatsApp Groups</Text>
      <Button colorScheme="blue" className="fetch-groups-button" onClick={fetchGroups} mb={4}>Fetch Groups</Button>

      <Joyride
        steps={steps}
        run={runTour}  // Tour runs based on this state
        continuous={true}  // Automatically go to the next step
        showProgress={true}  // Show step numbers
        showSkipButton={true}  // Show skip button
        styles={{
          options: {
            // backgroundColor: '#c1d2b',//color of the background
            // primaryColor: '#0c1d2b',//color of the Next button
            // textColor: '#ffffff',//color of the text
            // arrowColor: '#0c1d2b',
            // width: 500,
            // height: 500
          }
        }}
        callback={(data) => {
          const { status } = data;
          if (status === 'finished' || status === 'skipped') {
            setRunTour(false); // Stop the tour when finished or skipped
          }
        }}
      />

      {isLoading ? (
        <Spinner />
      ) : (
        <HStack alignItems="flex-start" spacing={8} height="330px">
          <VStack 
            spacing={4} 
            align="stretch" 
            flex={1} 
            overflowY="auto" 
            maxHeight="100%"
            css={{
              '&::-webkit-scrollbar': {
                width: '2px',
              },
              '&::-webkit-scrollbar-track': {
                width: '2px',
              },
              '&::-webkit-scrollbar-thumb': {
                background: 'gray',
                borderRadius: '24px',
              },
              '&::-webkit-scrollbar-thumb:hover': {
                background: 'darkgray',
              },
              '&': {
                scrollbarWidth: 'thin',
                scrollbarColor: 'gray transparent',
              },
            }}
          >
            {groups.map((group) => (
              <HStack
                key={group.groupId}
                width="100%"
                borderWidth={1}
                borderRadius="md"
                p={2}
                cursor="pointer"
                className="group-item"
                onClick={() => fetchGroupMembers(group.groupId)}
                bg={selectedGroup === group.groupId ? "blue.100" : "white"}
                _hover={{ backgroundColor: "gray.100" }}
              >
                <Image 
                  src={group.profileLink || '/av.png'} 
                  boxSize="50px" 
                  borderRadius="md" 
                  alt="Group Image" 
                />
                <VStack align="start">
                  <Text fontSize="lg" fontWeight="bold">{group.groupName}</Text>
                </VStack>
              </HStack>
            ))}
          </VStack>

          {selectedGroup && (
            <VStack 
              spacing={4} 
              align="stretch" 
              flex={1} 
              borderWidth={1} 
              borderRadius="lg" 
              p={4} 
              boxShadow="md" 
              bg="white" 
              className="group-members" 
              overflowY="auto" 
              maxHeight="100%"
              css={{
                '&::-webkit-scrollbar': {
                  width: '4px',
                },
                '&::-webkit-scrollbar-track': {
                  width: '6px',
                },
                '&::-webkit-scrollbar-thumb': {
                  background: 'gray',
                  borderRadius: '24px',
                },
                '&::-webkit-scrollbar-thumb:hover': {
                  background: 'darkgray',
                },
                '&': {
                  scrollbarWidth: 'thin',
                  scrollbarColor: 'gray transparent',
                },
              }}
            >
              <Text fontSize="xl" fontWeight="bold" color="blue.600" mb={2}>Group Members</Text>
              {groupMembers.map((member) => (
                <HStack 
                  key={member.memberNumber} 
                  borderWidth={1} 
                  borderRadius="md" 
                  p={3}
                  bg="gray.50"
                  _hover={{ bg: "blue.50", transition: "all 0.2s" }}
                  transition="all 0.2s"
                >
                  <Avatar size="sm" name={member.memberName} src={`https://api.dicebear.com/6.x/initials/svg?seed=${member.memberName}`} />
                  <VStack align="start" spacing={0}>
                    <Text fontWeight="medium">{member.memberName}</Text>
                    <Text fontSize="sm" color="gray.500">{member.memberNumber}</Text>
                  </VStack>
                </HStack>
              ))}
            </VStack>
          )}
        </HStack>
      )}
    </Box>
  );
};

export default GroupManager;
