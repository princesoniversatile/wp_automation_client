import { Box, Button, Input, Text, VStack, HStack, Select, Textarea } from "@chakra-ui/react";
import { useState } from "react";

const WhatsappDashboard = () => {
  // State Management
  const [message, setMessage] = useState("");
  const [numbers, setNumbers] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("");
  const [groups, setGroups] = useState([]);
  const [groupMembers, setGroupMembers] = useState([]);

  // Fetch WhatsApp Groups Handler
  const fetchGroups = async () => {
    // Example Fetch Groups API Call
    const groupData = await fetch("/api/get-groups").then(res => res.json());
    setGroups(groupData);
  };

  // Fetch Group Members Handler
  const fetchGroupMembers = async (groupId) => {
    const memberData = await fetch(`/api/get-group-members/${groupId}`).then(res => res.json());
    setGroupMembers(memberData);
  };

  // Handle Message Sending
  const sendMessage = (type) => {
    const data = {
      numbers: numbers.split(","),
      message,
      type, // "text" or "image"
    };
    console.log("Sending message data:", data);
    // You can send this to your backend API to trigger WhatsApp messages
  };

  return (
    <VStack align="start" spacing={8} padding={5}>
      {/* Panel 1: Send Message */}
      <Box width="100%" borderWidth={1} padding={4} borderRadius="lg">
        <Text fontSize="lg" fontWeight="bold">Send Message</Text>
        <Textarea
          placeholder="Enter message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          mb={3}
        />
        <Textarea
          placeholder="Enter comma-separated numbers..."
          value={numbers}
          onChange={(e) => setNumbers(e.target.value)}
        />
        <HStack spacing={4} mt={4}>
          <Button colorScheme="blue" onClick={() => sendMessage("text")}>Send Text</Button>
          <Button colorScheme="green" onClick={() => sendMessage("image")}>Send Image</Button>
        </HStack>
      </Box>

      {/* Panel 2: Fetch Group Information */}
      {/* <Box width="100%" borderWidth={1} padding={4} borderRadius="lg">
        <Text fontSize="lg" fontWeight="bold">Group Information</Text>
        <Button mt={3} onClick={fetchGroups}>Fetch WhatsApp Groups</Button>
        <Select
          mt={3}
          placeholder="Select group"
          onChange={(e) => {
            setSelectedGroup(e.target.value);
            fetchGroupMembers(e.target.value);
          }}
        >
          {groups.map((group) => (
            <option key={group.id} value={group.id}>
              {group.name} (ID: {group.id})
            </option>
          ))}
        </Select>
      </Box> */}

      {/* Panel 3: Get Group Members */}
      {/* {selectedGroup && (
        <Box width="100%" borderWidth={1} padding={4} borderRadius="lg">
          <Text fontSize="lg" fontWeight="bold">Group Members</Text>
          {groupMembers.length > 0 ? (
            groupMembers.map((member, index) => (
              <HStack key={index} justifyContent="space-between" borderBottom="1px solid #eaeaea" p={2}>
                <Text>{member.name}</Text>
                <Text>{member.number}</Text>
              </HStack>
            ))
          ) : (
            <Text mt={3}>No members found or group is empty.</Text>
          )}
        </Box>
      )} */}
    </VStack>
  );
};

export default WhatsappDashboard;
