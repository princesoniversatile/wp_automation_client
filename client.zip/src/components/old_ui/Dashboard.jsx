import { HStack } from "@chakra-ui/react";
import { useState } from "react";
import Navbar from "./Nav";
import MessageSender from "./MessageSender";
import GroupManager from "./GroupManager";
import MessageHistory from "./MessageHistory";

const Dashboard = () => {
  const [activeComponent, setActiveComponent] = useState("message"); // Default to MessageSender

  return (
    <>
      <Navbar setActiveComponent={setActiveComponent} />
      <HStack padding={8} justifyContent="center">
        {activeComponent === "message" ? (
          <MessageSender />
        ) : activeComponent === "group" ? (
          <GroupManager />
        ) : (
          <MessageHistory />
        )}
      </HStack>
    </>
  );
};

export default Dashboard;
