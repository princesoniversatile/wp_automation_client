import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import {
  Box,
  Grid,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  VStack,
  Heading,
  Text,
  Progress,
  Button,
  useColorModeValue,
  Flex
} from '@chakra-ui/react';
import { Line } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
import { RepeatIcon } from '@chakra-ui/icons';

Chart.register(...registerables);

const API_URL = import.meta.env.VITE_APP_API_URL;

const DashView = () => {
  const [dashboardData, setDashboardData] = useState({
    messageBalance: 0,
    totalCampaigns: 0,
    todayCampaigns: 0,
    totalSentMessages: 0,
    percentageUsed: 0,
    totalLimit: 0,
    usedLimit: 0,
    currentLimit: 0,
    campaigns: []
  });
  const [isLoading, setLoading] = useState(true);

  const cardBg = useColorModeValue('white', 'gray.800');
  const textColor = useColorModeValue('gray.600', 'gray.200');
  const statNumberColor = useColorModeValue('gray.900', 'white');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const cardColors = ['blue', 'purple', 'green','orange'];

  const user = JSON.parse(localStorage.getItem('user'))


  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [statisticsResponse, limitsResponse] = await Promise.all([
        axios.get(`${API_URL}/dashboard?email=${user.email}`),
        axios.get(`${API_URL}/getCreditLimit?emailId=${user.email}`)
      ]);

      

      const statistics = statisticsResponse.data.statistics;
      const limits = limitsResponse.data;

      setDashboardData({
        messageBalance: statistics.availableMessageBalance,
        totalCampaigns: statistics.totalCampaigns,
        todayCampaigns: statistics.todayCampaigns,
        totalSentMessages: statistics.totalSentMessages,
        percentageUsed: (limits.messageCount / limits.creditLimit) * 100,
        totalLimit: limits.creditLimit,
        usedLimit: limits.messageCount,
        currentLimit: limits,
        campaigns: [
          { label: 'Total Campaigns', value: statistics.totalCampaigns, type: 'increase' },
          { label: 'Today Campaigns', value: statistics.todayCampaigns, type: 'decrease' },
          { label: 'Total Sent Messages', value: statistics.totalSentMessages, type: 'increase' }
        ]
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const chartData = {
    labels: dashboardData.campaigns.map(item => item.label),
    datasets: [{
      label: 'Campaign Performance',
      data: dashboardData.campaigns.map(item => item.value),
      fill: false,
      backgroundColor: 'rgba(136, 132, 216, 0.6)',
      borderColor: 'rgba(136, 132, 216, 1)',
    }],
  };

  const chartOptions = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: borderColor },
      },
      x: {
        grid: { display: false },
      },
    },
  };

  const renderStatCard = (label, value, type, index) => (
    <Card bg={cardBg} borderColor={borderColor} borderWidth="1px" boxShadow="sm">
      <CardBody>
        <Stat>
          <StatLabel color={textColor}>{label}</StatLabel>
          <StatNumber color={statNumberColor} fontSize="2xl">
            {isLoading ? 'Loading...' : value.toLocaleString()}
          </StatNumber>
          <StatHelpText>
            <StatArrow type={type} />
            {type === 'increase' ? '+' : '-'}{Math.floor(Math.random() * 100)}%
          </StatHelpText>
        </Stat>
        <Progress 
          value={isLoading ? 0 : value} 
          colorScheme={cardColors[index]}
          size="xs"
          borderRadius="full"
        />
      </CardBody>
    </Card>
  );

  return (
    <Box p={6} bg={useColorModeValue('gray.50', 'gray.900')}>
      <Grid
        templateColumns={{
          base: 'repeat(1, 1fr)',
          md: 'repeat(2, 1fr)',
          lg: 'repeat(4, 1fr)'
        }}
        gap={6}
        mb={8}
      >
        {renderStatCard('Available Message Balance', dashboardData.totalLimit, 'increase', 0)}
        {dashboardData.campaigns.map((item, index) => (
          <Box key={item.label}>
            {renderStatCard(item.label, item.value, item.type, index + 1)}
          </Box>
        ))}
      </Grid>

      <Grid templateColumns={{ base: '1fr', lg: '1fr 1fr' }} gap={6}>
        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px" boxShadow="sm">
          <CardBody>
            <Flex justify="space-between" align="center" mb={4}>
              <Heading size="md" color={statNumberColor}>Campaign Performance</Heading>
              <Button
                leftIcon={<RepeatIcon />}
                colorScheme="purple"
                variant="ghost"
                size="sm"
                onClick={fetchData}
              >
                Refresh
              </Button>
            </Flex>
            <Box h="220px">
              <Line data={chartData} options={chartOptions} />
            </Box>
          </CardBody>
        </Card>

        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px" boxShadow="sm">
          <CardBody>
            <VStack spacing={5} align="stretch">
              <Flex justify="space-between" align="center">
                <Heading size="md" color={statNumberColor}>Credit Status</Heading>
                <Button
                  leftIcon={<RepeatIcon />}
                  colorScheme="purple"
                  variant="ghost"
                  size="sm"
                  onClick={fetchData}
                >
                  Refresh
                </Button>
              </Flex>

              <Box>
                <Flex justify="space-between" mb={2}>
                  <Text fontSize="sm" color={textColor}>Usage Overview</Text>
                  <Text fontSize="sm" color={textColor}>
                    {dashboardData.percentageUsed.toFixed(1)}%
                  </Text>
                </Flex>
                <Progress
                  value={dashboardData.percentageUsed}
                  colorScheme={dashboardData.percentageUsed > 80 ? 'red' : 'purple'}
                  size="sm"
                  borderRadius="full"
                />
              </Box>

              <Grid templateColumns="repeat(3, 1fr)" gap={4}>
                {[
                  { label: 'Total', value: dashboardData.totalLimit + dashboardData.usedLimit },
                  { label: 'Used', value: dashboardData.usedLimit },
                  { label: 'Remaining', value: dashboardData.totalLimit }
                ].map(({ label, value }) => (
                  <Stat key={label}>
                    <StatLabel color={textColor}>{label}</StatLabel>
                    <StatNumber color={statNumberColor}>
                      {value.toLocaleString()}
                    </StatNumber>
                  </Stat>
                ))}
              </Grid>
            </VStack>
          </CardBody>
        </Card>
      </Grid>
    </Box>
  );
};

export default DashView;