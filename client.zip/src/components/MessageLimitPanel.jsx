import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  GridItem,
  Heading,
  Input,
  Text,
  useToast,
  VStack,
  HStack,
  Image,
  Alert,
  AlertIcon,
  useColorModeValue,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Progress,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  Select
} from '@chakra-ui/react';

import { RepeatIcon } from '@chakra-ui/icons';
import axios from 'axios';

const MessageLimitPanel = ({ fetchCreditLimit }) => {
  const [messageLimit, setMessageLimit] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [currentLimit, setCurrentLimit] = useState({});
  const [totalLimit, setTotalLimit] = useState(0);
  const [usedLimit, setUsedLimit] = useState(0);
  const [percentageUsed, setPercentageUsed] = useState(0);
  const [selectedUser, setSelectedUser] = useState('');
  const [users, setUsers] = useState([]);
  const [balanceType, setBalanceType] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [remainingLimit, setRemainingLimit] = useState(0);

  const toast = useToast();

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');
  const textColor = useColorModeValue('gray.700', 'gray.200');
  const headingColor = useColorModeValue('gray.700', 'gray.200');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getAllUsers`);
        const apiUsers = response.data.map((user) => ({
          id: user._id,
          name: user.username,                         
          email: user.emailId,
          type: user.type,
          creditLimit: user.creditLimit,
          companyName: user.companyName || 'N/A',
          contactPerson: user.contactPerson || 'N/A',
        }));
        console.log(apiUsers);
        setUsers(apiUsers);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast({
          title: 'Error fetching users.',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
      }
    };

    fetchUsers();
  }, [fetchCreditLimit]);

  const getEmailById = (userId) => {
    const user = users.find((user) => user.id === userId);
    console.log(`selected user is ${user.email}`);
    return user ? user.email : '';
  };

  const checkConnectionStatus = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/check-status`);
      setIsConnected(response.data.connected);
    } catch (error) {
      console.error('Error fetching connection status:', error);
      setIsConnected(false);
      toast({
        title: 'Error fetching connection status.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const fetchCurrentLimit = async () => {
    try {
      // const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getCreditLimit?emailId=${getEmailById(selectedUser)}`);
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getCreditLimit?emailId=${getEmailById(selectedUser)}`);
      setCurrentLimit(response.data);
      // setTotalLimit(response.data.creditLimit);
      // setUsedLimit(response.data.messageCount);
      // setPercentageUsed((response.data.messageCount / response.data.maxMessagesPerMinute) * 100);
      setTotalLimit(response.data.creditLimit || 0);
setUsedLimit(response.data.messageCount || 0);
setPercentageUsed(((response.data.messageCount || 0) / (response.data.creditLimit || 1)) * 100);
    } catch (error) {
      console.error('Error fetching current limit:', error);
      toast({
        title: 'Error fetching current limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleLimitSubmit = async () => {
    try {
      const emailId = getEmailById(selectedUser);

      if (!emailId) {
        toast({
          title: 'User ke liye Email ID nahi mili.',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
        return;
      }

      let response;
      try {
        response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/updateBalance`, {
          emailId,
          amount: parseInt(messageLimit, 10),
          type: balanceType
        });
      } catch (error) {
        console.error('Error updating balance:', error);
        toast({
          title: 'Failed to update balance.',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
        return;
      }

      console.log('Message limit set successfully:', response.data);
      toast({
        title: 'Balance updated successfully!',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });

      // Call fetchCreditLimit after successful balance update
      await fetchCreditLimit();

      // Refresh the current limit displayed in this component
      await fetchCurrentLimit();
    } catch (error) {
      console.error('Error setting message limit:', error);
      toast({
        title: 'Failed to update balance.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // useEffect(() => {
  //   const initialize = async () => {
  //     await checkConnectionStatus();
  //     await fetchCurrentLimit();
  //   };
  //   initialize();
  // }, [selectedUser]);
  useEffect(() => {
    const initialize = async () => {
      await checkConnectionStatus();
      if (selectedUser) {
        await fetchCurrentLimit();
      }
    };
    initialize();
  }, [selectedUser]); // 'handleLimitSubmit' ki dependency hata do
  

  const handleRefresh = () => {
    setMessageLimit(''); 
    checkConnectionStatus();
    fetchCurrentLimit();
  };

  const handleLimitChange = (event) => {
    setMessageLimit(event.target.value);
  };


  useEffect(() => {
    if (!isNaN(currentLimit.maxMessagesPerMinute) && !isNaN(currentLimit.messageCount)) {
      setRemainingLimit(currentLimit.maxMessagesPerMinute - currentLimit.messageCount);
    }
  }, [handleRefresh]);

  return (
    <Box
      bg={bgColor}
      p={4}
      borderRadius="lg"
      boxShadow="xl"
      maxWidth="1000px"
      margin="auto"
      display="flex"
      flexDirection="column"
      alignItems="center"
    >
      <Button
        leftIcon={<RepeatIcon transform="rotate(180deg)" />}
        colorScheme="blue"
        onClick={handleRefresh}
        width="full"
        mb={6}
      >
        Refresh Data
      </Button>

      <Box width="100%" px={4}>
        <Grid 
          templateColumns="repeat(12, 1fr)" 
          gap={10} 
          mb={6} 
          width="100%"
          justifyContent="space-between"
        >
          <GridItem colSpan={[12, 5, 6]}>
            <VStack spacing={10} align="center" justifyContent="center">
              <Heading as="h5" size="md" mb={2}>
                CREDIT MANAGEMENT
              </Heading>

              <Select
                placeholder="Select Balance Type"
                value={balanceType}
                onChange={(e) => setBalanceType(e.target.value)}
                mb={2}
                bg={balanceType === 'credit' ? 'green.100' : balanceType === 'debit' ? 'red.100' : 'gray.100'}
                _hover={{ bg: balanceType === 'credit' ? 'green.200' : balanceType === 'debit' ? 'red.200' : 'gray.200' }}
              >
                <option value="credit" style={{ backgroundColor: '#34C759',color:'white',fontWeight:'bold' }}>Credit Balance</option>
                <option value="debit" style={{ backgroundColor: 'red',color:'white',fontWeight:'bold' }}>Debit Balance</option>
              </Select>
              
              <Select
                placeholder="Select User"
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                mb={2}
              >
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name}
                  </option>
                ))}
              </Select>

              <Input
                placeholder="Enter Balance Amount"
                value={messageLimit}
                type="number"
                onChange={handleLimitChange}
                mb={2}
              />
              <Button colorScheme="blue" onClick={handleLimitSubmit} width="full">
                Submit
              </Button>
            </VStack>
          </GridItem>

          <GridItem colSpan={[12, 5, 6]}>
            <Box bg={useColorModeValue('gray.100', 'gray.700')} p={4} borderRadius="md" boxShadow="md">
              <Heading as="h6" size="sm" mb={4} textAlign="center" color={textColor}>
                Usage Overview
              </Heading>
              <VStack spacing={4} align="stretch" alignContent="stretch">
                <Progress
                  value={percentageUsed}
                  size="lg"
                  colorScheme={percentageUsed > 80 ? "red" : "green"}
                  borderRadius="full"
                />
                <Stat>
                  <StatLabel color={textColor} style={{ fontWeight: 'bold' }}>Total Credit Balance</StatLabel>
                  <StatNumber color={headingColor}  >{totalLimit}</StatNumber>
                  <StatHelpText color={textColor}>Total available messages</StatHelpText>
                </Stat>
                <Stat>
                  <StatLabel color={textColor} style={{ fontWeight: 'bold' }}>Used Limit</StatLabel>
                  <StatNumber color={headingColor}>{usedLimit}</StatNumber>
                  <StatHelpText color={textColor}>Messages used so far</StatHelpText>
                </Stat>
              
              </VStack>
            </Box>
          </GridItem>
        </Grid>
      </Box>

    
    </Box>
  );
};

export default MessageLimitPanel;
