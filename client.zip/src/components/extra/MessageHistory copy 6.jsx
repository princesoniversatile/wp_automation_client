import React, { useState, useEffect } from 'react';
import {
  Box,
  Heading,
  useColorModeValue,
  Spinner,
  Text,
  Badge,
  HStack,
  Button,
  VStack,
  Container,
  useToast,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Tag,
  Input,
  Select,
  Flex,
  IconButton,
  Tooltip,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
} from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon, DownloadIcon, DragHandleIcon as FilterIcon , SearchIcon } from '@chakra-ui/icons';
import axios from 'axios';
import * as XLSX from 'xlsx';

const MessageHistory = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDateTime, setStartDateTime] = useState('');
  const [endDateTime, setEndDateTime] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [sortField, setSortField] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');
  const [filterField, setFilterField] = useState('');
  const [filterValue, setFilterValue] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  const bgColor = useColorModeValue('gray.50', 'gray.800');
  const cardBgColor = useColorModeValue('white', 'gray.700');
  const textColor = useColorModeValue('gray.800', 'gray.100');
  const borderColor = useColorModeValue('gray.200', 'gray.600');

  const toast = useToast();
  const { isOpen, onOpen, onClose } = useDisclosure();

  useEffect(() => {
    fetchMessageHistory();
  }, []);

  const fetchMessageHistory = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get('http://192.168.29.100:4001/getMessageHistory');
      if (response.data.success) {
        const processedData = response.data.messages.map(message => {
          const [datePart, timePart] = message.date.split(' ');
          const [day, month, year] = datePart.split('/');
          const jsDate = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}`);
          return {
            ...message,
            jsDate
          };
        });
        setHistory(processedData);
      } else {
        throw new Error('Failed to fetch message history');
      }
    } catch (error) {
      console.error('Error fetching message history:', error);
      setError('Failed to load message history. Please try again later.');
      toast({
        title: "Error",
        description: "Failed to load message history. Please try again later.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterByDateTime = (data) => {
    if (!startDateTime && !endDateTime) return data;
    
    return data.filter(message => {
      const messageDate = message.jsDate;
      const start = startDateTime ? new Date(startDateTime) : null;
      const end = endDateTime ? new Date(endDateTime) : null;
      return (
        (!start || messageDate >= start) &&
        (!end || messageDate <= end)
      );
    });
  };

  const sortData = (data) => {
    return data.sort((a, b) => {
      if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1;
      if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  };

  const filterData = (data) => {
    if (!filterField || !filterValue) return data;
    return data.filter(item => 
      item[filterField].toLowerCase().includes(filterValue.toLowerCase())
    );
  };

  const searchData = (data) => {
    if (!searchQuery) return data;
    return data.filter(item =>
      Object.values(item).some(val =>
        val.toString().toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  };

  const exportToExcel = () => {
    const filteredData = filterByDateTime(searchData(filterData(sortData(history))));
    const worksheet = XLSX.utils.json_to_sheet(filteredData.map(item => ({
      'Sent On': item.date,
      'Recipient': item.recipient,
      'Message': item.message,
      'Status': item.status,
      'Type': item.type
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Message History');
    XLSX.writeFile(workbook, 'message_history.xlsx');

    toast({
      title: "Export Successful",
      description: "Message history has been exported to Excel.",
      status: "success",
      duration: 3000,
      isClosable: true,
    });
  };

  const handleSort = (field) => {
    setSortDirection(sortField === field && sortDirection === 'asc' ? 'desc' : 'asc');
    setSortField(field);
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filterByDateTime(searchData(filterData(sortData(history)))).slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  if (isLoading) {
    return (
      <Box textAlign="center" mt={10}>
        <Spinner size="xl" color="teal.500" />
        <Text mt={4} color={textColor}>Loading message history...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" mt={10}>
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Container maxW="container.xl">
      <VStack spacing={6} align="stretch">
        <Box
          bg={cardBgColor}
          p={6}
          borderRadius="lg"
          boxShadow="xl"
          borderWidth="1px"
          borderColor={borderColor}
        >
          <VStack spacing={6} align="stretch">
            <Flex justifyContent="space-between" alignItems="center">
              <Heading as="h2" size="xl" color={textColor}>
                <HStack spacing={2} alignItems="center">
                  <Text fontSize="2xl" fontWeight="bold" color="blue.600">
                    Communication History Insights
                  </Text>
                  <Badge colorScheme="blue" fontSize="sm" variant="solid">
                    Beta
                  </Badge>
                </HStack>
              </Heading>
              <HStack>
                <Tooltip label="Filter">
                  <IconButton icon={<FilterIcon />} onClick={onOpen} aria-label="Filter" />
                </Tooltip>
                <Tooltip label="Export to Excel">
                  <IconButton icon={<DownloadIcon />} onClick={exportToExcel} aria-label="Export to Excel" />
                </Tooltip>
              </HStack>
            </Flex>
            
            <Flex>
              <Input
                placeholder="Search messages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                mr={2}
              />
              <IconButton icon={<SearchIcon />} aria-label="Search" />
            </Flex>

            <Box 
              bg={useColorModeValue('white', 'gray.800')}
              boxShadow="md"
              borderRadius="md"
              overflow="hidden"
            >
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th onClick={() => handleSort('date')} cursor="pointer">Sent On {sortField === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}</Th>
                    <Th onClick={() => handleSort('recipient')} cursor="pointer">Recipient {sortField === 'recipient' && (sortDirection === 'asc' ? '↑' : '↓')}</Th>
                    <Th>Message</Th>
                    <Th onClick={() => handleSort('status')} cursor="pointer">Status {sortField === 'status' && (sortDirection === 'asc' ? '↑' : '↓')}</Th>
                    <Th onClick={() => handleSort('type')} cursor="pointer">Type {sortField === 'type' && (sortDirection === 'asc' ? '↑' : '↓')}</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {currentItems.map((item, index) => (
                    <Tr key={index}>
                      <Td>{item.date}</Td>
                      <Td>{item.recipient}</Td>
                      <Td>{item.message}</Td>
                      <Td>
                        <Tag
                          colorScheme={item.status === 'sent' ? 'green' : item.status === 'failed' ? 'red' : 'blue'}
                        >
                          {item.status}
                        </Tag>
                      </Td>
                      <Td>{item.type}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>
            <Flex justifyContent="space-between" alignItems="center">
              <Text>
                Showing {indexOfFirstItem + 1} to {Math.min(indexOfLastItem, history.length)} of {history.length} entries
              </Text>
              <HStack>
                <IconButton
                  icon={<ChevronLeftIcon />}
                  onClick={() => paginate(currentPage - 1)}
                  isDisabled={currentPage === 1}
                  aria-label="Previous page"
                />
                <Text>{currentPage}</Text>
                <IconButton
                  icon={<ChevronRightIcon />}
                  onClick={() => paginate(currentPage + 1)}
                  isDisabled={indexOfLastItem >= history.length}
                  aria-label="Next page"
                />
              </HStack>
            </Flex>
          </VStack>
        </Box>
      </VStack>

      <Drawer isOpen={isOpen} placement="right" onClose={onClose}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Filter Messages</DrawerHeader>
          <DrawerBody>
            <VStack spacing={4}>
              <Input
                type="datetime-local"
                value={startDateTime}
                onChange={(e) => setStartDateTime(e.target.value)}
                placeholder="Start Date & Time"
              />
              <Input
                type="datetime-local"
                value={endDateTime}
                onChange={(e) => setEndDateTime(e.target.value)}
                placeholder="End Date & Time"
              />
              <Select
                value={filterField}
                onChange={(e) => setFilterField(e.target.value)}
                placeholder="Filter by"
              >
                <option value="recipient">Recipient</option>
                <option value="status">Status</option>
                <option value="type">Type</option>
              </Select>
              <Input
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
                placeholder="Filter value"
              />
              <Button onClick={onClose} colorScheme="blue">Apply Filters</Button>
            </VStack>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </Container>
  );
};

export default MessageHistory;