import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css"; // Updated theme import
import {
  Box,
  Heading,
  useColorModeValue,
  Spinner,
  Text,
  Badge,
  HStack,
  Button,
} from '@chakra-ui/react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import * as XLSX from 'xlsx';

const MessageHistory = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDateTime, setStartDateTime] = useState(null);
  const [endDateTime, setEndDateTime] = useState(null);
  
  const bgColor = useColorModeValue('#f4f4f4', '#1a202c');
  const textColor = useColorModeValue('#2d3748', '#f0e68c');
  const borderColor = useColorModeValue('#e2e8f0', '#4a5568');

  useEffect(() => {
    const fetchMessageHistory = async () => {
      try {
        setIsLoading(true);
        const response = await axios.get('http://192.168.29.100:4001/getMessageHistory');
        if (response.data.success) {
          const processedData = response.data.messages.map(message => {
            const [datePart, timePart] = message.date.split(' ');
            const [day, month, year] = datePart.split('/');
            const jsDate = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}`);
            return {
              ...message,
              jsDate
            };
          });
          setHistory(processedData);
        } else {
          throw new Error('Failed to fetch message history');
        }
      } catch (error) {
        console.error('Error fetching message history:', error);
        setError('Failed to load message history. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchMessageHistory();
  }, []);

  const filterByDateTime = (data) => {
    if (!startDateTime && !endDateTime) return data;
    
    return data.filter(message => {
      const messageDate = message.jsDate;
      return (
        (!startDateTime || messageDate >= startDateTime) &&
        (!endDateTime || messageDate <= endDateTime)
      );
    });
  };

  const columnDefs = [
    {
      headerName: 'Sent On',
      field: 'date',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Recipient',
      field: 'recipient',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Message',
      field: 'message',
      flex: 2,
      cellRenderer: params => (
        <div style={{ maxWidth: '300px', whiteSpace: 'normal', lineHeight: '1.4', textAlign: 'center' }}>
          {params.value}
        </div>
      ),
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Status',
      field: 'status',
      sortable: true,
      filter: true,
      flex: 1,
      cellRenderer: params => (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
          <Badge colorScheme={params.value === 'sent' ? 'green' : params.value === 'failed' ? 'red' : 'blue'}>
            {params.value}
          </Badge>
        </div>
      ),
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Type',
      field: 'type',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
    },
  ];

  const defaultColDef = {
    resizable: true,
    sortable: true,
    filter: true,
    headerClass: 'ag-header-cell-center',
  };

  const exportToExcel = () => {
    const filteredData = filterByDateTime(history);
    const worksheet = XLSX.utils.json_to_sheet(filteredData.map(item => ({
      'Sent On': item.date,
      'Recipient': item.recipient,
      'Message': item.message,
      'Status': item.status,
      'Type': item.type
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Message History');
    XLSX.writeFile(workbook, 'message_history.xlsx');
  };

  if (isLoading) {
    return (
      <Box textAlign="center" mt={10}>
        <Spinner size="xl" color="teal.500" />
        <Text mt={4} color={textColor}>Loading message history...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" mt={10}>
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Box
      bg={bgColor}
      p={6}
      borderRadius="lg"
      boxShadow="2xl"
      width="100%"
      borderWidth="1px"
      borderColor={borderColor}
    >
      <Heading as="h2" size="xl" mb={6} color={textColor} fontWeight="bold">
        Campaign History
      </Heading>
      
      <HStack spacing={4} mb={4}>
        <DatePicker
          selected={startDateTime}
          onChange={date => setStartDateTime(date)}
          showTimeSelect
          timeFormat="HH:mm"
          timeIntervals={15}
          timeCaption="Time"
          dateFormat="dd/MM/yyyy HH:mm"
          placeholderText="Start Date & Time"
          isClearable
          customInput={
            <input
              style={{
                padding: '8px',
                borderRadius: '4px',
                border: '1px solid #ccc',
              }}
            />
          }
        />
        <DatePicker
          selected={endDateTime}
          onChange={date => setEndDateTime(date)}
          showTimeSelect
          timeFormat="HH:mm"
          timeIntervals={15}
          timeCaption="Time"
          dateFormat="dd/MM/yyyy HH:mm"
          placeholderText="End Date & Time"
          isClearable
          customInput={
            <input
              style={{
                padding: '8px',
                borderRadius: '4px',
                border: '1px solid #ccc',
              }}
            />
          }
        />
        <Button onClick={exportToExcel} colorScheme="teal">
          Export to Excel
        </Button>
      </HStack>

      <Box 
        className="ag-theme-alpine" // Updated class name for the new theme
        style={{ 
          height: '330px', 
          width: '100%',
        }}
      >
        <AgGridReact
          rowData={filterByDateTime(history)}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          pagination={true}
          paginationPageSize={10}
          suppressCellFocus={true}
          enableCellTextSelection={true}
          animateRows={true}
        />
      </Box>
    </Box>
  );
};

export default MessageHistory;