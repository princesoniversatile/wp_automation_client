import React, { useState, useEffect } from 'react';
import {
  Box,
  Heading,
  useColorModeValue,
  Spinner,
  Text,
  Badge,
  HStack,
  Button,
  TextField,
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import axios from 'axios';
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { ko } from 'date-fns/locale'; // Adjust if you need a different locale
import * as XLSX from 'xlsx';

const MessageHistory = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDateTime, setStartDateTime] = useState(null);
  const [endDateTime, setEndDateTime] = useState(null);
  
  const bgColor = useColorModeValue('#f4f4f4', '#1a202c');
  const textColor = useColorModeValue('#2d3748', '#f0e68c');
  const borderColor = useColorModeValue('#e2e8f0', '#4a5568');

  useEffect(() => {
    const fetchMessageHistory = async () => {
      try {
        setIsLoading(true);
        const response = await axios.get('http://192.168.29.100:4001/getMessageHistory');
        if (response.data.success) {
          const processedData = response.data.messages.map(message => {
            const [datePart, timePart] = message.date.split(' ');
            const [day, month, year] = datePart.split('/');
            const jsDate = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}`);
            return {
              ...message,
              jsDate
            };
          });
          setHistory(processedData);
        } else {
          throw new Error('Failed to fetch message history');
        }
      } catch (error) {
        console.error('Error fetching message history:', error);
        setError('Failed to load message history. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchMessageHistory();
  }, []);

  const filterByDateTime = (data) => {
    if (!startDateTime && !endDateTime) return data;

    return data.filter(message => {
      const messageDate = message.jsDate;
      return (
        (!startDateTime || messageDate >= startDateTime) &&
        (!endDateTime || messageDate <= endDateTime)
      );
    });
  };

  const columns = [
    { field: 'date', headerName: 'Sent On', flex: 1, headerAlign: 'center', align: 'center' },
    { field: 'recipient', headerName: 'Recipient', flex: 1, headerAlign: 'center', align: 'center' },
    {
      field: 'message',
      headerName: 'Message',
      flex: 2,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <div style={{ maxWidth: '300px', whiteSpace: 'normal', lineHeight: '1.4', textAlign: 'center' }}>
          {params.value}
        </div>
      ),
    },
    {
      field: 'status',
      headerName: 'Status',
      flex: 1,
      headerAlign: 'center',
      align: 'center',
      renderCell: (params) => (
        <Badge colorScheme={params.value === 'sent' ? 'green' : params.value === 'failed' ? 'red' : 'blue'}>
          {params.value}
        </Badge>
      ),
    },
    { field: 'type', headerName: 'Type', flex: 1, headerAlign: 'center', align: 'center' },
  ];

  const exportToExcel = () => {
    const filteredData = filterByDateTime(history);
    const worksheet = XLSX.utils.json_to_sheet(filteredData.map(item => ({
      'Sent On': item.date,
      'Recipient': item.recipient,
      'Message': item.message,
      'Status': item.status,
      'Type': item.type
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Message History');
    XLSX.writeFile(workbook, 'message_history.xlsx');
  };

  if (isLoading) {
    return (
      <Box textAlign="center" mt={10}>
        <Spinner size="xl" color="teal.500" />
        <Text mt={4} color={textColor}>Loading message history...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" mt={10}>
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Box
      sx={{ 
        backgroundColor: bgColor, 
        p: 4, 
        borderRadius: 2, 
        boxShadow: 3, 
        width: '100%', 
        borderColor: borderColor,
      }}
    >
      <Heading as="h2" size="xl" mb={4} color={textColor}>
        Campaign History
      </Heading>
      
      <HStack spacing={2} mb={4}>
        <LocalizationProvider dateAdapter={AdapterDateFns} locale={ko}>
          <DateTimePicker
            label="Start Date & Time"
            value={startDateTime}
            onChange={setStartDateTime}
            renderInput={(params) => <TextField {...params} variant="outlined" />}
          />
          <DateTimePicker
            label="End Date & Time"
            value={endDateTime}
            onChange={setEndDateTime}
            renderInput={(params) => <TextField {...params} variant="outlined" />}
          />
        </LocalizationProvider>
        <Button variant="contained" onClick={exportToExcel} color="primary">
          Export to Excel
        </Button>
      </HStack>

      <div style={{ height: 400, width: '100%' }}>
        <DataGrid
          rows={filterByDateTime(history)}
          columns={columns}
          pageSize={10}
          rowsPerPageOptions={[5, 10, 20]}
          disableSelectionOnClick
        />
      </div>
    </Box>
  );
};

export default MessageHistory;
