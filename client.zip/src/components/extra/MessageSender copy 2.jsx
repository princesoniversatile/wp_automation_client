import {
  Box,
  Button,
  Input,
  Textarea,
  VStack,
  Text,
  Alert,
  AlertIcon,
  Tag,
  TagCloseButton,
  TagLabel,
  Image,
  HStack,
  Wrap,
  WrapItem,
  useColorModeValue,
  useToast
} from '@chakra-ui/react'
import { useState } from 'react'
import axios from 'axios'

const MessageSender = () => {
  const [message, setMessage] = useState('')
  const [numbers, setNumbers] = useState('')
  const [alert, setAlert] = useState({ status: false, message: '', type: '' })
  const [recipients, setRecipients] = useState([])
  const [imageFile, setImageFile] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [isSending, setIsSending] = useState(false)

  const toast = useToast()

  // Color mode values
  const bgColor = useColorModeValue('white', 'gray.800')
  const borderColor = useColorModeValue('gray.200', 'gray.600')
  const textColor = useColorModeValue('gray.800', 'white')
  const inputBgColor = useColorModeValue('gray.50', 'gray.700')

  // Handle message sending logic
  const sendMessage = async (type) => {
    if (recipients.length === 0 || !message) {
      setAlert({
        status: true,
        message: 'Please enter a message and at least one recipient number.',
        type: 'error'
      })
      return
    }

    setIsSending(true)

    for (const number of recipients) {
      try {
        let response
        if (type === 'text') {
          response = await axios.get(`http://localhost:4001/send?message=${encodeURIComponent(message)}&number=${number}`)
        } else if (type === 'image' && imageFile) {
          const formData = new FormData()
          formData.append('file', imageFile)
          response = await axios.post(`http://localhost:4001/send-link?link=${encodeURIComponent(URL.createObjectURL(imageFile))}&number=${number}&fileName=${imageFile.name}`, formData)
        }

        if (response.data === 'good') {
          toast({
            title: 'Message Sent',
            description: `Message sent successfully to ${number}`,
            status: 'success',
            duration: 3000,
            isClosable: true,
          })
        } else {
          throw new Error('Unexpected response')
        }
      } catch (error) {
        toast({
          title: 'Error',
          description: `Failed to send message to ${number}: ${error.message}`,
          status: 'error',
          duration: 3000,
          isClosable: true,
        })
      }

      // Wait for 2 seconds before sending the next message (rate limiting)
      await new Promise(resolve => setTimeout(resolve, 2000))
    }

    setIsSending(false)

    // Resetting fields after sending
    setImageFile(null)
    setImagePreview(null)
    setMessage('')
    setNumbers('')
    setRecipients([])
    setAlert({
      status: true,
      message: 'All messages sent!',
      type: 'success'
    })
  }

  // Function to validate and add recipients
  const addRecipient = () => {
    if (numbers) {
      const newNumbers = numbers
        .split(',')
        .map(num => num.trim())
        .filter(num => validateNumber(num) && !recipients.includes(num)) // Validate numbers and check for duplicates
      if (newNumbers.length > 0) {
        setRecipients(prev => [...prev, ...newNumbers])
        setNumbers('') // Clear input after adding
      } else {
        setAlert({
          status: true,
          message: 'The number is not valid or already added.',
          type: 'warning'
        })
      }
    }
  }

  const handleNumberInput = e => {
    const inputValue = e.target.value
    setNumbers(inputValue)

    if (inputValue.endsWith(',')) {
      addRecipient()
    }
  }

  // Function to validate Indian phone numbers
  const validateNumber = num => {
    const indianNumberPattern = /^[6-9]\d{9}$/
    if (!indianNumberPattern.test(num)) {
      setAlert({
        status: true,
        message: `Invalid number: ${num}. It should be 10 digits and start with 6-9.`,
        type: 'error'
      })
      return false
    }
    return true
  }

  // Function to remove recipient
  const removeRecipient = numToRemove => {
    setRecipients(recipients.filter(num => num !== numToRemove))
  }

  // Handle image file selection
  const handleImageChange = e => {
    const file = e.target.files[0]
    if (file) {
      // Check if the file is an image
      if (!file.type.startsWith('image/')) {
        setAlert({
          status: true,
          message: 'Please select a valid image file.',
          type: 'error'
        })
        return
      }

      // Check file size (limit to 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setAlert({
          status: true,
          message: 'Image file size should be less than 5MB.',
          type: 'error'
        })
        return
      }

      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => setImagePreview(reader.result)
      reader.onerror = () => {
        setAlert({
          status: true,
          message: 'Error reading the image file.',
          type: 'error'
        })
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <Box
      borderWidth={1}
      borderRadius='lg'
      p={6}
      width='100%'
      boxShadow='dark-lg'
      bg={bgColor}
      borderColor={borderColor}
    >
      <Text fontSize='2xl' fontWeight='bold' mb={6} color={textColor}>
        Send WhatsApp Message
      </Text>

      {/* Alert for success/error messages */}
      {alert.status && (
        <Alert
          status={alert.type === 'error' ? 'error' : 'success'}
          mb={5}
          borderRadius='md'
        >
          <AlertIcon />
          {alert.message}
        </Alert>
      )}
      

      <Textarea
        placeholder='Enter your message...'
        value={message}
        onChange={e => setMessage(e.target.value)}
        mb={4}
        resize='none'
        rows={4}
        bg={inputBgColor}
        borderColor={borderColor}
        _hover={{ borderColor: 'blue.500' }}
        _focus={{ borderColor: 'blue.500', boxShadow: '0 0 0 1px blue.500' }}
      />

      {/* Recipients Input */}
      <Input
        type='text' // Change type to text for better control
        placeholder='Add recipient numbers and press Enter...'
        value={numbers}
        onChange={handleNumberInput}
        onKeyDown={e => {
          // Allow only numbers and comma
          if (!/^[0-9,]*$/.test(e.key) && e.key !== 'Backspace') {
            e.preventDefault() // Prevent default behavior for invalid keys
          }
          if (e.key === 'Enter') {
            addRecipient()
          }
        }}
        mb={4}
        bg={inputBgColor}
        borderColor={borderColor}
        _hover={{ borderColor: 'blue.500' }}
        _focus={{ borderColor: 'blue.500', boxShadow: '0 0 0 1px blue.500' }}
      />

      {/* Recipients Chips */}
      <Wrap spacing={2} mb={4}>
        {recipients.map((num, index) => (
          <WrapItem key={index}>
            <Tag
              size='lg'
              variant='solid'
              colorScheme='blue'
              mb={1}
              maxWidth='100%'
              borderRadius='full'
            >
              <TagLabel isTruncated>{num}</TagLabel>
              <TagCloseButton onClick={() => removeRecipient(num)} />
            </Tag>
          </WrapItem>
        ))}
      </Wrap>

     {/* Image Input and Preview */}
<Input
  type='file'
  accept='image/*'
  onChange={handleImageChange}
  mb={4}
  p={1}
  bg={inputBgColor}
  borderColor={borderColor}
/>

{imagePreview && (
  <Box mb={4} position="relative">
    <Image
      src={imagePreview}
      alt='Selected Image'
      maxHeight='200px'
      objectFit='cover'
      borderRadius='md'
    />
    <Button
      position="absolute"
      top={0}
      right={0}
      colorScheme='red'
      onClick={() => {
        setImagePreview(null); // Remove the image preview
        setImageFile(null); // Clear the file
      }}
    >
      Remove
    </Button>
  </Box>
)}



      <VStack spacing={4} mt={6}>
        <Button
          colorScheme='blue'
          onClick={() => sendMessage('text')}
          width='100%'
          size='lg'
          isLoading={isSending}
          loadingText="Sending..."
        >
          Send Text
        </Button>
        <Button
          colorScheme='green'
          onClick={() => sendMessage('image')}
          isDisabled={!imageFile || isSending}
          width='100%'
          size='lg'
          isLoading={isSending}
          loadingText="Sending..."
        >
          Send Image
        </Button>
      </VStack>
    </Box>
  )
}

export default MessageSender
