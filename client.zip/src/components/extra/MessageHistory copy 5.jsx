import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-material.css";
import {
  Box,
  Heading,
  useColorModeValue,
  Spinner,
  Text,
  Badge,
  HStack,
  Button,
  Tag,
  VStack,
  Container,
  useToast,
  Flex,
} from '@chakra-ui/react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import * as XLSX from 'xlsx';

const MessageHistory = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDateTime, setStartDateTime] = useState(null);
  const [endDateTime, setEndDateTime] = useState(null);
  
  const bgColor = useColorModeValue('gray.50', 'gray.800');
  const cardBgColor = useColorModeValue('white', 'gray.700');
  const textColor = useColorModeValue('gray.800', 'gray.100');
  const borderColor = useColorModeValue('gray.200', 'gray.600');

  const toast = useToast();

  useEffect(() => {
    const fetchMessageHistory = async () => {
      try {
        setIsLoading(true);
        const response = await axios.get('http://192.168.29.100:4001/getMessageHistory');
        if (response.data.success) {
          const processedData = response.data.messages.map(message => {
            const [datePart, timePart] = message.date.split(' ');
            const [day, month, year] = datePart.split('/');
            const jsDate = new Date(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}T${timePart}`);
            return {
              ...message,
              jsDate
            };
          });
          setHistory(processedData);
        } else {
          throw new Error('Failed to fetch message history');
        }
      } catch (error) {
        console.error('Error fetching message history:', error);
        setError('Failed to load message history. Please try again later.');
        toast({
          title: "Error",
          description: "Failed to load message history. Please try again later.",
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchMessageHistory();
  }, [toast]);

  const filterByDateTime = (data) => {
    if (!startDateTime && !endDateTime) return data;
    
    return data.filter(message => {
      const messageDate = message.jsDate;
      return (
        (!startDateTime || messageDate >= startDateTime) &&
        (!endDateTime || messageDate <= endDateTime)
      );
    });
  };

  const columnDefs = [
    {
      headerName: 'Sent On',
      field: 'date',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
      cellClass: 'ag-cell-center',
    },
    {
      headerName: 'Recipient',
      field: 'recipient',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Message',
      field: 'message',
      flex: 2,
      cellStyle: { textAlign: 'center' },
      cellRenderer: params => (
        <div style={{ maxWidth: '300px', whiteSpace: 'normal', textAlign: 'center' }}>
          {params.value}
        </div>
      ),
      headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Status',
      field: 'status',
      sortable: true,
      filter: true,
      flex: 2,
      cellRenderer: params => (
        <Flex justifyContent="center" alignItems="center" height="100%">
          <Tag
            size="sm"
            variant="solid"
            colorScheme={params.value === 'sent' ? 'green' : params.value === 'failed' ? 'red' : 'blue'}
            borderRadius="full"
            textTransform="uppercase"
             whiteSpace='normal'
             textAlign='center'
             position='unset !important'
          >
            {params.value}
          </Tag>
        </Flex>
      ),
      // headerClass: 'ag-header-cell-center',
    },
    {
      headerName: 'Type',
      field: 'type',
      sortable: true,
      filter: true,
      flex: 1,
      cellStyle: { textAlign: 'center' },
      headerClass: 'ag-header-cell-center',
    },
  ];

  const defaultColDef = {
    resizable: true,
    sortable: true,
    filter: true,
    headerClass: 'ag-header-cell-center',
  };

  const exportToExcel = () => {
    const filteredData = filterByDateTime(history);
    const worksheet = XLSX.utils.json_to_sheet(filteredData.map(item => ({
      'Sent On': item.date,
      'Recipient': item.recipient,
      'Message': item.message,
      'Status': item.status,
      'Type': item.type
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Message History');
    XLSX.writeFile(workbook, 'message_history.xlsx');

    toast({
      title: "Export Successful",
      description: "Message history has been exported to Excel.",
      status: "success",
      duration: 3000,
      isClosable: true,
    });
  };

  if (isLoading) {
    return (
      <Box textAlign="center" mt={10}>
        <Spinner size="xl" color="teal.500" />
        <Text mt={4} color={textColor}>Loading message history...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" mt={10}>
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Container maxW="container.xl" >
      <VStack spacing={6} align="stretch">
        <Box
          bg={cardBgColor}
          p={4}
          borderRadius="lg"
          boxShadow="xl"
          borderWidth="1px"
          borderColor={borderColor}
        >
          <VStack spacing={4} align="stretch">
            <Heading as="h2" size="xl" color={textColor}>
              <HStack spacing={2} alignItems="center">
                <Text fontSize="2xl" fontWeight="bold" color="blue.600">
                  Communication History Insights
                </Text>
                <Badge colorScheme="blue" fontSize="sm" variant="solid">
                  Beta
                </Badge>
              </HStack>
            </Heading>
            
            <HStack spacing={4} wrap="wrap">
              {/* <DatePicker
                selected={startDateTime}
                onChange={date => setStartDateTime(date)}
                showTimeSelect
                timeFormat="HH:mm"
                timeIntervals={15}
                timeCaption="Time"
                dateFormat="dd/MM/yyyy HH:mm"
                placeholderText="Start Date & Time"
                isClearable
                customInput={
                  <Button variant="outline" colorScheme="teal">
                    {startDateTime ? startDateTime.toLocaleString() : "Start Date & Time"}
                  </Button>
                }
              />
              <DatePicker
                selected={endDateTime}
                onChange={date => setEndDateTime(date)}
                showTimeSelect
                timeFormat="HH:mm"
                timeIntervals={15}
                timeCaption="Time"
                dateFormat="dd/MM/yyyy HH:mm"
                placeholderText="End Date & Time"
                isClearable
                customInput={
                  <Button variant="outline" colorScheme="teal">
                    {endDateTime ? endDateTime.toLocaleString() : "End Date & Time"}
                  </Button>
                }
              /> */}
              <Button onClick={exportToExcel} colorScheme="blue" leftIcon={<i className="fas fa-file-excel" />}>
                Export to Excel
              </Button>
            </HStack>

            <Box 
              className="ag-theme-material"
              bg={useColorModeValue('white', 'gray.800')}
              _hover={{ bg: useColorModeValue('gray.800', 'gray.900') }}
              boxShadow="md"
              borderRadius="md"
              overflow="hidden"
              height="500px"
              width="100%"
            >
              <AgGridReact
                rowData={filterByDateTime(history)}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                pagination={true}
                paginationPageSize={15}
                suppressCellFocus={true}
                enableCellTextSelection={true}
                animateRows={true}
              />
            </Box>
          </VStack>
        </Box>
      </VStack>
    </Container>
  );
};

export default MessageHistory;