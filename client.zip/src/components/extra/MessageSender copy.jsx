import { Box, Button, Input, Textarea, VStack, Text, Alert, AlertIcon } from "@chakra-ui/react";
import { useState } from "react";

const MessageSender = () => {
  const [message, setMessage] = useState("");
  const [numbers, setNumbers] = useState("");
  const [alert, setAlert] = useState({ status: false, message: "", type: "" });

  // Handle message sending logic
  const sendMessage = (type) => {
    const recipientNumbers = numbers.split(",").map(num => num.trim());

    if (recipientNumbers.length === 0 || !message) {
      setAlert({ status: true, message: "Please enter a message and at least one recipient number.", type: "error" });
      return;
    }

    console.log({
      numbers: recipientNumbers,
      message,
      type,
    });

    // Resetting fields after sending
    setMessage("");
    setNumbers("");
    setAlert({ status: true, message: "Message sent successfully!", type: "success" });
  };

  return (
    <Box borderWidth={1} borderRadius="lg" p={5} width="100%" boxShadow="md">
      <Text fontSize="xl" fontWeight="bold" mb={4}>Send WhatsApp Message</Text>
      
      {/* Alert for success/error messages */}
      {alert.status && (
        <Alert status={alert.type === "error" ? "error" : "success"} mb={4}>
          <AlertIcon />
          {alert.message}
        </Alert>
      )}

      <Textarea
        placeholder="Enter your message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        mb={3}
        resize="none" // Disable resizing
        rows={4} // Set default rows
      />
      <Textarea
        placeholder="Enter comma-separated numbers..."
        value={numbers}
        onChange={(e) => setNumbers(e.target.value)}
        mb={3}
        resize="none" // Disable resizing
        rows={2} // Set default rows
      />
      <VStack spacing={3} mt={4}>
        <Button colorScheme="blue" onClick={() => sendMessage("text")}>Send Text</Button>
        <Button colorScheme="green" onClick={() => sendMessage("image")}>Send Image</Button>
      </VStack>
    </Box>
  );
};

export default MessageSender;
