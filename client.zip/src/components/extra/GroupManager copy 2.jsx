import { Box, Button, Input, HStack, VStack, Text, Image, Spinner, Avatar } from "@chakra-ui/react";
import { useState, useEffect } from "react";

const GroupManager = () => {
  const [groups, setGroups] = useState([]); // Groups data
  const [selectedGroup, setSelectedGroup] = useState(null); // Selected group ID
  const [groupMembers, setGroupMembers] = useState([]); // Group members data
  const [isLoading, setIsLoading] = useState(false); // Loading state

  // Fetch group data
  const fetchGroups = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://192.168.29.100:4001/groupData');
      const { data } = await response.json(); // Response structure has 'data' key
      setGroups(data); // Set the fetched groups
    } catch (error) {
      console.error("Error fetching groups:", error);
    }
    setIsLoading(false);
  };

  // Fetch group members
  const fetchGroupMembers = async (groupId) => {
    setIsLoading(true);
    try {
      const response = await fetch(`http://192.168.29.100:4001/getMembers/${groupId}`);
      const { members } = await response.json(); // Response structure has 'members' key
      setGroupMembers(members); // Set the fetched members
      setSelectedGroup(groupId); // Set the selected group ID
    } catch (error) {
      console.error("Error fetching group members:", error);
    }
    setIsLoading(false);
  };

  return (
    <Box borderWidth={1} borderRadius="lg" p={5} width="100%" boxShadow="md">
      <Text fontSize="xl" fontWeight="bold" mb={4}>Manage WhatsApp Groups</Text>
      <Button colorScheme="blue" onClick={fetchGroups} mb={4}>Fetch Groups</Button>

      {isLoading ? (
        <Spinner />
      ) : (
        <HStack alignItems="flex-start" spacing={8}>
          <VStack spacing={4} align="stretch" flex={1}>
            {groups.map((group) => (
              <HStack
                key={group.groupId}
                width="100%"
                borderWidth={1}
                borderRadius="md"
                p={3}
                cursor="pointer"
                onClick={() => fetchGroupMembers(group.groupId)}
                bg={selectedGroup === group.groupId ? "blue.100" : "white"}
                _hover={{ backgroundColor: "gray.100" }}
              >
                <Image 
                  src={group.profileLink || '/av.png'} 
                  boxSize="50px" 
                  borderRadius="md" 
                  alt="Group Image" 
                />
                <VStack align="start">
                  <Text fontSize="lg" fontWeight="bold">{group.groupName}</Text>
                </VStack>
              </HStack>
            ))}
          </VStack>

          {selectedGroup && (
            <VStack spacing={4} align="stretch" flex={1} borderWidth={1} borderRadius="lg" p={4} boxShadow="md" bg="white">
              <Text fontSize="xl" fontWeight="bold" color="blue.600" mb={2}>Group Members</Text>
              {groupMembers.map((member) => (
                <HStack 
                  key={member.memberNumber} 
                  borderWidth={1} 
                  borderRadius="md" 
                  p={3}
                  bg="gray.50"
                  _hover={{ bg: "blue.50", transition: "all 0.2s" }}
                  transition="all 0.2s"
                >
                  <Avatar size="sm" name={member.memberName} src={`https://api.dicebear.com/6.x/initials/svg?seed=${member.memberName}`} />
                  <VStack align="start" spacing={0}>
                    <Text fontWeight="medium">{member.memberName}</Text>
                    <Text fontSize="sm" color="gray.500">{member.memberNumber}</Text>
                  </VStack>
                </HStack>
              ))}
            </VStack>
          )}
        </HStack>
      )}
    </Box>
  );
};

export default GroupManager;
