import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Heading,
  useToast,
  Container,
  InputGroup,
  InputRightElement,
  IconButton,
} from '@chakra-ui/react';
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons';
import axios from 'axios';

const ChangePassword = () => {
  const [passwords, setPasswords] = useState({
    current: '',
    new: '',
    confirm: '',
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  });
  const [isLoading, setIsLoading] = useState(false);
 
  const toast = useToast();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPasswords(prev => ({ ...prev, [name]: value }));
  };

  const togglePasswordVisibility = (field) => {
    setShowPasswords(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      toast({
        title: 'Passwords do not match',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    setIsLoading(true);
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const response = await axios.post(
        `${import.meta.env.VITE_APP_API_URL}/change-password`,
        {
          email: user.email,
          currentPassword: passwords.current,
          newPassword: passwords.new,
        },
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );

      if (response.data.success) {
        toast({
          title: 'Password changed successfully',
          description: 'Your password has been updated.',
          status: 'success',
          duration: 5000,
          isClosable: true,
          position: 'bottom',
        });
        setPasswords({ current: '', new: '', confirm: '' });
      } else {
        throw new Error(response.data.message || 'Failed to change password');
      }
    } catch (error) {
      toast({
        // title: 'Error',
        description: error.response?.data?.message || error.message || 'An error occurred while changing the password',
        status: 'error',
        duration: 5000,
        isClosable: true,
        position: 'top',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container maxW="container.md" py={8}>
      <Box
        borderWidth={1}
        borderRadius="md"
        p={6}
        boxShadow="md"
        bg="white"
      >
        <VStack spacing={6} align="stretch">
          <Heading size="md" textAlign="center" color="blue.600">Change Password</Heading>
          <form onSubmit={handleSubmit}>
            <VStack spacing={4}>
              {['current', 'new', 'confirm'].map((field) => (
                <FormControl key={field} isRequired>
                  <FormLabel>{field.charAt(0).toUpperCase() + field.slice(1)} Password</FormLabel>
                  <InputGroup size="md">
                    <Input
                      name={field}
                      type={showPasswords[field] ? 'text' : 'password'}
                      value={passwords[field]}
                      onChange={handleInputChange}
                    />
                    <InputRightElement>
                      <IconButton
                        size="sm"
                        icon={showPasswords[field] ? <ViewOffIcon /> : <ViewIcon />}
                        onClick={() => togglePasswordVisibility(field)}
                        variant="ghost"
                        aria-label={`Toggle ${field} password visibility`}
                      />
                    </InputRightElement>
                  </InputGroup>
                </FormControl>
              ))}
              <Button 
                type="submit" 
                colorScheme="blue" 
                size="md" 
                width="full"
                isLoading={isLoading}
                loadingText="Changing Password"
              >
                Change Password
              </Button>
            </VStack>
          </form>
        </VStack>
      </Box>
    </Container>
  );
};

export default ChangePassword;
