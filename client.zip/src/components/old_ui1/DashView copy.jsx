import React, { useState, useEffect } from 'react'
import axios from 'axios'

import {
  Box,
  Grid,
  GridItem,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  TableContainer,
  Table,
  Thead,
  Tr,
  Th,
  Tbody,
  Td,
  Tfoot
} from '@chakra-ui/react'

const DashView = () => {
  const [messageBalance, setMessageBalance] = useState(0)
  const [totalCampaigns, setTotalCampaigns] = useState(0)
  const [todayCampaigns, setTodayCampaigns] = useState(0)
  const [totalSentMessages, setTotalSentMessages] = useState(0)

  useEffect(() => {
    axios.get(`${import.meta.env.VITE_API_URL}/api/message-balance`)
      .then(response => {
        setMessageBalance(response.data.balance)
      })
    axios.get(`${import.meta.env.VITE_API_URL}/api/total-campaigns`)
      .then(response => {
        setTotalCampaigns(response.data.campaigns)
      })
    axios.get(`${import.meta.env.VITE_API_URL}/api/today-campaigns`)
      .then(response => {
        setTodayCampaigns(response.data.campaigns)
      })
    axios.get(`${import.meta.env.VITE_API_URL}/api/total-sent-messages`)
      .then(response => {
        setTotalSentMessages(response.data.messages)
      })
  }, [])

  return (
    <>
      <Box p='5' bis_skin_checked='1'>
        <Grid
          templateColumns='repeat(4, 1fr)'
          gap={6}
          mb='6'
          bis_skin_checked='1'
        >
          {[
            { label: 'Available Message Balance', value: messageBalance, type: 'increase' },
            { label: 'Total Campaigns', value: totalCampaigns, type: 'increase' },
            { label: 'Today Campaigns', value: todayCampaigns, type: 'decrease' },
            { label: 'Total Sent Messages', value: totalSentMessages, type: 'increase' }
          ].map((item, index) => (
            <GridItem key={index} bis_skin_checked='1'>
              <Card
                overflow='hidden'
                variant='outline'
                bg='blackAlpha.900'
                bis_skin_checked='1'
              >
                <CardBody bis_skin_checked='1'>
                  <Stat bis_skin_checked='1'>
                    <StatLabel color='white'>{item.label}</StatLabel>
                    <StatNumber color='white'>{item.value}</StatNumber>
                    <StatHelpText color='white'>
                      <StatArrow
                        focusable='false'
                        aria-hidden='true'
                        type={item.type}
                      ></StatArrow>
                      {item.value}
                    </StatHelpText>
                  </Stat>
                </CardBody>
              </Card>
            </GridItem>
          ))}
        </Grid>
        <Grid templateColumns='repeat(12,1fr)' gap={6} bis_skin_checked='1'>
          <GridItem
            colSpan={{ base: 12, lg: 4 }}
            bis_skin_checked='1'
          ></GridItem>
          <GridItem
            colSpan={{ base: 12, lg: 8 }}
            bis_skin_checked='1'
          ></GridItem>
        </Grid>
      </Box>
    </>
  )
}

export default DashView
