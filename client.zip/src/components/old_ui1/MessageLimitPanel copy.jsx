
import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  GridItem,
  Heading,
  Input,
  Text,
  useToast,
  VStack,
  HStack,
  Image,
  Alert,
  AlertIcon,
  useColorModeValue,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td
} from '@chakra-ui/react';
import { RepeatIcon } from '@chakra-ui/icons';
import axios from 'axios';

const MessageLimitPanel = () => {
  const [messageLimit, setMessageLimit] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [currentLimit, setCurrentLimit] = useState({});
  const toast = useToast();

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const fetchQrCode = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get('http://localhost:4001/qrimage', {
        responseType: 'blob',
      });
      const imageUrl = URL.createObjectURL(response.data);
      setQrCode(imageUrl);
    } catch (error) {
      setError('QR code not available. Please try again later.');
      toast({
        title: 'Failed to load QR code.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const checkConnectionStatus = async () => {
    try {
      const response = await axios.get('http://localhost:4001/check-status');
      setIsConnected(response.data.connected);
    } catch (error) {
      console.error('Error fetching connection status:', error);
      setIsConnected(false);
      toast({
        title: 'Error fetching connection status.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const fetchCurrentLimit = async () => {
    try {
      const response = await axios.get('http://localhost:4001/getApiLimit');
      setCurrentLimit(response.data);
    } catch (error) {
      console.error('Error fetching current limit:', error);
      toast({
        title: 'Error fetching current limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleLimitSubmit = async () => {
    try {
      const response = await axios.post('http://localhost:4001/setApiLimit', {
        maxMessagesPerMinute: messageLimit,
      });
      console.log('Message limit set successfully:', response.data);
      toast({
        title: 'Message limit set successfully!',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error setting message limit:', error);
      toast({
        title: 'Failed to set message limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  useEffect(() => {
    const initialize = async () => {
      await fetchQrCode();
      await checkConnectionStatus();
      await fetchCurrentLimit();
    };
    initialize();
  }, []);

  const handleRefresh = () => {
    setMessageLimit(''); 
    fetchQrCode(); 
    checkConnectionStatus();
    fetchCurrentLimit();
  };

  const handleLimitChange = (event) => {
    setMessageLimit(event.target.value);
  };

  const remainingLimit = currentLimit.maxMessagesPerMinute - currentLimit.messageCount;

  return (
    <Box
      bg={bgColor}
      p={8}
      borderRadius="lg"
      boxShadow="xl"
      maxWidth="1000px"
      margin="auto"
      display="flex"
      flexDirection="column"
      alignItems="center"
    >

      <Button
        leftIcon={<RepeatIcon />}
        colorScheme="blue"
        onClick={handleRefresh}
        width="full"
        mb={6}
      >
        Refresh Data
      </Button>
      <Grid templateColumns="repeat(12, 1fr)" gap={6} mb={6}>
        <GridItem colSpan={[12, 12, 4]}>
          <VStack spacing={4} align="stretch">
            <Heading as="h5" size="md" mb={2}>
              Configure Message Limit
            </Heading>
            <Input
              placeholder="Message Limit"
              value={messageLimit}
              type="number"
              onChange={handleLimitChange}
              mb={2}
            />
            <Button colorScheme="blue" onClick={handleLimitSubmit} width="full">
              Set Limit
            </Button>
          </VStack>
        </GridItem>
        {/* <GridItem colSpan={[12, 12, 4]}>
          <Box>
            <Heading as="h5" size="md" mb={4}>
              WhatsApp Connection
            </Heading>
            <VStack spacing={4} align="center">
              <Box>
                {loading ? (
                  <CircularProgress isIndeterminate />
                ) : qrCode ? (
                  <Image src={qrCode} alt="QR Code" maxWidth="100%" mb={2} />
                ) : (
                  <Alert status="warning" mb={2}>
                    <AlertIcon />
                    {error}
                  </Alert>
                )}
              </Box>
              <HStack>
                <Box
                  w={4}
                  h={4}
                  borderRadius="full"
                  bg={isConnected ? "green.500" : "red.500"}
                />
                <Text>{isConnected ? 'Connected' : 'Disconnected'}</Text>
              </HStack>
            </VStack>
          </Box>
        </GridItem> */}
        <GridItem colSpan={[12, 12, 4]} position="relative" bottom={0} right={0}>
          <Box bg={useColorModeValue('gray.100', 'gray.700')} p={4} borderRadius="md" boxShadow="md">
            <Heading as="h6" size="sm" mb={2} textAlign="center">Message Limits</Heading>
            <Table size="md" textAlign="center">
              <Thead>
                <Tr>
                  <Th>Category</Th>
                  <Th>Value</Th>
                </Tr>
              </Thead>
              <Tbody>
                <Tr>
                  <Td><strong>Available Limit:</strong></Td>
                  <Td>{currentLimit.maxMessagesPerMinute}</Td>
                </Tr>
                <Tr>
                  <Td><strong>Sent:</strong></Td>
                  <Td>{currentLimit.messageCount}</Td>
                </Tr>
                <Tr>
                  <Td><strong>Remaining:</strong></Td>
                  <Td>{remainingLimit}</Td>
                </Tr>
              </Tbody>
            </Table>
          </Box>
        </GridItem>
      </Grid>
    </Box>
  );
};


export default MessageLimitPanel;
