import {
  IconButton,
  Avatar,
  Box,
  CloseButton,
  Flex,
  HStack,
  VStack,
  Icon,
  useColorModeValue,
  Text,
  Drawer,
  DrawerContent,
  useDisclosure,
  Menu,
  MenuButton,
  MenuDivider,
  MenuItem,
  MenuList,
  Image,
} from '@chakra-ui/react'
import { Link } from 'react-router-dom'
import {
  FiMenu,
  FiBell,
  FiChevronDown,
  FiMessageSquare,
  FiUsers,
  FiList,
  FiSettings,
} from 'react-icons/fi'
import { TbMessage2Off } from "react-icons/tb";

import { useState } from "react";
import logo from '../assets/nsv.svg';
import MessageSender from "./MessageSender";
import GroupManager from "./GroupManager";
import MessageHistory from "./MessageHistory";
import MessageLimits from "./MessageLimits";
import ChangePassword from './ChangePassword';

const LinkItems = [
  { name: 'Send Message', icon: FiMessageSquare, component: 'message' },
  { name: 'Manage Groups', icon: FiUsers, component: 'group' },
  { name: 'Message History', icon: FiList, component: 'history' },
  { name: 'Message Limits', icon: TbMessage2Off, component: 'limits' },
]

const SidebarContent = ({ onClose, setActiveComponent, ...rest }) => {
  return (
    <Box
      transition="0.3s ease"
      bg={useColorModeValue('gray.50', 'gray.900')}
      borderRight="1px"
      borderRightColor={useColorModeValue('gray.200', 'gray.700')}
      w={{ base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      boxShadow="lg"
      {...rest}>
      <Flex h="20" alignItems="center" mx="6" justifyContent="space-between">
        <Image src={logo} alt="logo" width="40px" height="40px" />
        <CloseButton 
          display={{ base: 'flex', md: 'none' }} 
          onClick={onClose}
          color={useColorModeValue('gray.600', 'gray.200')}
        />
      </Flex>
      <VStack spacing={4} align="stretch" mt={6}>
        {LinkItems.map((link) => (
          <NavItem 
            key={link.name} 
            icon={link.icon} 
            component={link.component} 
            setActiveComponent={setActiveComponent}
            bg={useColorModeValue('white', 'gray.800')}
            color={useColorModeValue('gray.700', 'gray.300')}
            _hover={{
              bg: useColorModeValue('blue.50', 'blue.800'),
              color: 'blue.500',
            }}
            borderRadius="md"
            mx={3}
            p={5}
            boxShadow="sm"
            fontWeight="bold"
          >
            <Text fontWeight="bold">{link.name}</Text>
          </NavItem>
        ))}
      </VStack>
    </Box>
  )
}

const NavItem = ({ icon, children, component, setActiveComponent, ...rest }) => {
  return (
    <Box
      as="a"
      href="#"
      style={{ textDecoration: 'none' }}
      _focus={{ boxShadow: 'none' }}
      onClick={() => setActiveComponent(component)} // Active component change
    >
    
      <Flex
        align="center"
        p="4"
        mx="4"
        borderRadius="lg"
        role="group"
        cursor="pointer"
        _hover={{
          bg: 'blue.600',
          color: 'white',
        }}
        {...rest}>
        
        
        {icon && (
          <Icon
            mr="4"
            fontSize="16"
            _groupHover={{
              color: 'blue.600',
            }}
            as={icon}
          />
        )}
        {children}
      </Flex>
    </Box>
  )
}

const MobileNav = ({ onOpen,setActiveComponent, ...rest }) => {
  return (
    <Flex
      ml={{ base: 0, md: 60 }}
      px={{ base: 4, md: 4 }}
      height="20"
      alignItems="center"
      bg={useColorModeValue('white', 'gray.900')}
      borderBottomWidth="1px"
      borderBottomColor={useColorModeValue('gray.200', 'gray.700')}
      justifyContent={{ base: 'space-between', md: 'flex-end' }}
      {...rest}>
      <IconButton
        display={{ base: 'flex', md: 'none' }}
        onClick={onOpen}
        variant="outline"
        aria-label="open menu"
        icon={<FiMenu />}
      />
    <Text
      fontSize="2xl"
      display={{base: "none", md: "flex"}}
      fontWeight="bold"
      color={useColorModeValue("black", "gray.100")}
      bgGradient="linear(to-r, gray.800, black)"
      bgClip="text"
      position="start"
      flex={1}
    >
        Dashboard
      </Text>
      <Text
        display={{ base: 'flex', md: 'none' }}
        fontSize="2xl"
        fontFamily="monospace"
        fontWeight="bold">
        WhatsApp Automation
      </Text>

      <HStack spacing={{ base: '0', md: '6' }}>
        <IconButton size="lg" variant="ghost" aria-label="open menu" icon={<FiBell />} />
        <Flex alignItems={'center'}>
          <Menu>
            <MenuButton py={2} transition="all 0.3s" _focus={{ boxShadow: 'none' }}>
              <HStack>
                <Avatar
                  size={'sm'}
                  src={
                    'https://images.unsplash.com/photo-1619946794135-5bc917a27793?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&fit=crop&h=200&w=200&s=b616b2c5b373a80ffc9636ba24f7a4a9'
                  }
                />
                <VStack
                  display={{ base: 'none', md: 'flex' }}
                  alignItems="flex-start"
                  spacing="1px"
                  ml="2">
                  <Text fontSize="sm">Kuldeep Mathur</Text>
                  <Text fontSize="xs" color="gray.600">
                    Admin
                  </Text>
                </VStack>
                <Box display={{ base: 'none', md: 'flex' }}>
                  <FiChevronDown />
                </Box>
              </HStack>
            </MenuButton>
            <MenuList
              bg={useColorModeValue('white', 'gray.900')}
              borderColor={useColorModeValue('gray.200', 'gray.700')}>
              {/* <MenuItem>Profile</MenuItem> */}
              <MenuItem onClick={() => setActiveComponent('settings')}>Settings</MenuItem>
              <MenuItem onClick={() => setActiveComponent('changePassword')}>Change Password</MenuItem>
              {/* <MenuItem>Billing</MenuItem> */}
              <MenuDivider />
              <MenuItem as={Link} to="/login">Sign out</MenuItem>
            </MenuList>
          </Menu>
        </Flex>
      </HStack>
    </Flex>
  )
}

const Dashboard = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [activeComponent, setActiveComponent] = useState("changePassword")

  return (
    <Box minH="100vh" bg={useColorModeValue('gray.100', 'gray.900')}>
      <SidebarContent onClose={onClose} setActiveComponent={setActiveComponent} display={{ base: 'none', md: 'block' }} />
      <Drawer
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full">
        <DrawerContent>
          <SidebarContent onClose={onClose} setActiveComponent={setActiveComponent} />
        </DrawerContent>
      </Drawer>
      <MobileNav onOpen={onOpen} />
      <Box ml={{ base: 0, md: 60 }} p="4">
        {activeComponent === "message" ? (
          <MessageSender />
        ) : activeComponent === "group" ? (
          <GroupManager />
        ) : activeComponent === "limits" ? (
          <MessageLimits />
        ) : activeComponent === "changePassword" ? (
          <ChangePassword />
        ) : (
          <MessageHistory />
        )}
      </Box>
    </Box>
  )
}

export default Dashboard
