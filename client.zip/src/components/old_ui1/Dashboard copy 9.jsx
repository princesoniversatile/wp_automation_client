import {
  IconButton,
  Avatar,
  Box,
  CloseButton,
  Flex,
  HStack,
  VStack,
  Icon,
  useColorModeValue,
  Text,
  Drawer,
  DrawerContent,
  useDisclosure,
  Menu,
  MenuButton,
  MenuDivider,
  MenuItem,
  MenuList,
  Image,
  AvatarBadge,
} from '@chakra-ui/react'
import { Link, useNavigate } from 'react-router-dom'
import {
  FiMenu,
  FiBell,
  FiChevronDown,
  FiMessageSquare,
  FiUsers,
  FiList,
  FiSettings,
  FiZoomIn
} from 'react-icons/fi'
import { FiMessageCircle } from "react-icons/fi";

import { TbMessage2Off } from "react-icons/tb";

import { useEffect, useState } from "react";
import logo from '../assets/nsv.svg';
import MessageSender from "./MessageSender";
import GroupManager from "./GroupManager";
import MessageHistory from "./MessageHistory";
import MessageLimits from "./MessageLimits";
import ChangePassword from './ChangePassword';
import MessageLimitPanel from './MessageLimitPanel';

const LinkItems = [
  { name: 'Send Message', icon: FiMessageSquare, component: 'message' },
  { name: 'Manage Groups', icon: FiUsers, component: 'group' },
  { name: 'Message History', icon: FiList, component: 'history' },
  { name: 'Message Limits', icon: TbMessage2Off, component: 'limits' },
  { name: 'Message Limit Panel', icon: FiMessageCircle, component: 'limitPanel' },
]

const SidebarContent = ({ onClose, setActiveComponent, ...rest }) => {
  return (
    <Box
      transition="0.3s ease"
      bg={useColorModeValue('gray.100', 'gray.900')}
      borderRight="1px"
      borderRightColor={useColorModeValue('gray.200', 'gray.700')}
      w={{ base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      boxShadow="lg"
      {...rest}
    >
      <Flex h="20" alignItems="center" mx="6" justifyContent="space-between">
        <Box display="flex" alignItems="center" gap="5">
        <Image src={logo} alt="logo" width="40px" height="40px" />
                  <Text fontSize="xl" fontWeight="bold" color={useColorModeValue('gray.800', 'white')}>
            WhatsApp Automation
          </Text>
        </Box>
        <CloseButton 
          display={{ base: 'flex', md: 'none' }} 
          onClick={onClose}
          color={useColorModeValue('gray.600', 'gray.200')}
        />
      </Flex>
      <VStack spacing={4} align="stretch" mt={6}>
        {LinkItems.map((link) => (
          <NavItem 
            key={link.name} 
            icon={link.icon} 
            component={link.component} 
            setActiveComponent={setActiveComponent}
            bg={useColorModeValue('white', 'gray.800')}
            color={useColorModeValue('gray.700', 'gray.300')}
            _hover={{
              bg: useColorModeValue('teal.50', 'teal.900'),
              color: useColorModeValue('teal.700', 'teal.200'),
              transform: 'translateX(5px)',
              boxShadow: 'md',
            }}
            borderRadius="lg"
            mx={3}
            p={5}
            transition="all 0.3s"
          >
            <Text fontWeight="bold">{link.name}</Text>
          </NavItem>
        ))}
      </VStack>
    </Box>
  );
};

const NavItem = ({ icon, children, component, setActiveComponent, ...rest }) => {
  return (
    <Box
      as="a"
      href="#"
      style={{ textDecoration: 'none' }}
      _focus={{ boxShadow: 'none' }}
      onClick={() => setActiveComponent(component)}
    >
      <Flex
        align="center"
        p="4"
        mx="4"
        borderRadius="lg"
        role="group"
        cursor="pointer"
        _hover={{
          bg: 'blue.600',
          color: 'white',
        }}
        {...rest}>
        {icon && (
          <Icon
            mr="4"
            fontSize="16"
            _groupHover={{
              color: 'blue.600',
            }}
            as={icon}
          />
        )}
        {children}
      </Flex>
    </Box>
  )
}

const MobileNav = ({ onOpen, setActiveComponent, ...rest }) => {
  const navigate = useNavigate();

  const handleSignOut = () => {
    navigate('/login');
    localStorage.removeItem('user');
  };

  
  const [username, setUsername] = useState(''); 

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.username) {
      setUsername(user.username);
    }
  }, []);



  return (
    <Flex
      ml={{ base: 0, md: 60 }}
      px={{ base: 4, md: 4 }}
      height="20"
      alignItems="center"
      bg={useColorModeValue('white', 'gray.900')}
      borderBottomWidth="1px"
      borderBottomColor={useColorModeValue('gray.200', 'gray.700')}
      justifyContent={{ base: 'space-between', md: 'flex-end' }}
      {...rest}>
      <IconButton
        display={{ base: 'flex', md: 'none' }}
        onClick={onOpen}
        variant="outline"
        aria-label="open menu"
        icon={<FiMenu />}
      />
    <Text
      fontSize="2xl"
      display={{base: "none", md: "flex"}}
      fontWeight="bold"
      color={useColorModeValue("black", "gray.100")}
      bgGradient="linear(to-r, gray.800, black)"
      bgClip="text"
      position="start"
      flex={1}
    >
        Dashboard
      </Text>
      <Text
        display={{ base: 'flex', md: 'none' }}
        fontSize="2xl"
        fontFamily="monospace"
        fontWeight="bold">
        WhatsApp Automation
      </Text>

      <HStack spacing={{ base: '0', md: '6' }}>
        <IconButton size="lg" variant="ghost" aria-label="open menu" icon={<FiBell />} />
        <Flex alignItems={'center'}>
          <Menu>
            <MenuButton py={2} transition="all 0.3s" _focus={{ boxShadow: 'none' }}>
              <HStack>
                <Avatar
                  size={'md'}
                  src={
                    'https://cdn4.iconfinder.com/data/icons/business-set-3-part-2/128/Favorite_User-512.png'
                  }
                />
                <VStack
                  display={{ base: 'none', md: 'flex' }}
                  alignItems="flex-start"
                  spacing="1px"
                  ml="2">
                  <Text fontSize="sm">{username}</Text>
                  <Text fontSize="xs" color="gray.600">
                    Admin
                  </Text>
                </VStack>
                <Box display={{ base: 'none', md: 'flex' }}>
                  <FiChevronDown />
                </Box>
              </HStack>
            </MenuButton>
            <MenuList
              bg={useColorModeValue('white', 'gray.900')}
              borderColor={useColorModeValue('gray.200', 'gray.700')}>
              <MenuItem onClick={() => setActiveComponent('changePassword')}>Change Password</MenuItem>
              <MenuDivider />
              <MenuItem onClick={handleSignOut}>Sign out</MenuItem>
            </MenuList>
          </Menu>
        </Flex>
      </HStack>
    </Flex>
  )
}

const Dashboard = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [activeComponent, setActiveComponent] = useState("limitPanel")

  return (
    <Box minH="100vh" bg={useColorModeValue('gray.100', 'gray.900')}>
      <SidebarContent onClose={onClose} setActiveComponent={setActiveComponent} display={{ base: 'none', md: 'block' }} />
      <Drawer
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full">
        <DrawerContent>
          <SidebarContent onClose={onClose} setActiveComponent={setActiveComponent} />
        </DrawerContent>
      </Drawer>
      <MobileNav onOpen={onOpen} setActiveComponent={setActiveComponent} />
      <Box ml={{ base: 0, md: 60 }} p="4">
        {activeComponent === "message" ? (
          <MessageSender />
        ) : activeComponent === "group" ? (
          <GroupManager />
        ) : activeComponent === "limits" ? (
          <MessageLimits />
        ) : activeComponent === "changePassword" ? (
          <ChangePassword />
        ) : activeComponent === "limitPanel" ? (
          <MessageLimitPanel />
        ) : (
          <MessageHistory />
        )}
      </Box>
    </Box>
  )
}

export default Dashboard
