import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  Box,
  Grid,
  GridItem,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  VStack,
  HStack,
  Heading,
  Text,
  Progress,
  Button,
  useColorModeValue
} from '@chakra-ui/react'
import { Line } from 'react-chartjs-2'
import { Chart, registerables } from 'chart.js'

// Register all necessary components
Chart.register(...registerables)

const DashView = () => {
  const [messageBalance, setMessageBalance] = useState(0)
  const [totalCampaigns, setTotalCampaigns] = useState(0)
  const [todayCampaigns, setTodayCampaigns] = useState(0)
  const [totalSentMessages, setTotalSentMessages] = useState(0)
  const [percentageUsed, setPercentageUsed] = useState(0)
  const [totalLimit, setTotalLimit] = useState(0)
  const [usedLimit, setUsedLimit] = useState(0)
  const [campaigns, setCampaigns] = useState([])

  const bgColor = useColorModeValue('gray.700', 'gray.700')
  const headingColor = useColorModeValue('gray.200', 'gray.200')
  const textColor = useColorModeValue('gray.200', 'gray.200')

  useEffect(() => {
    fetchStatistics()
    fetchLimits()
  }, [])

  const fetchStatistics = async () => {
    const response = await axios.get(
      `${import.meta.env.VITE_APP_API_URL}/dashboard`
    )
    const statistics = response.data.statistics
    setMessageBalance(statistics.availableMessageBalance)
    setTotalCampaigns(statistics.totalCampaigns)
    setTodayCampaigns(statistics.todayCampaigns)
    setTotalSentMessages(statistics.totalSentMessages)

    setCampaigns([
      {
        label: 'Available Message Balance',
        value: statistics.availableMessageBalance,
        type: 'increase'
      },
      {
        label: 'Total Campaigns',
        value: statistics.totalCampaigns,
        type: 'increase'
      },
      {
        label: 'Today Campaigns',
        value: statistics.todayCampaigns,
        type: 'decrease'
      },
      {
        label: 'Total Sent Messages',
        value: statistics.totalSentMessages,
        type: 'increase'
      }
    ])
  }

  const fetchLimits = async () => {
    const response = await axios.get(
      `${import.meta.env.VITE_APP_API_URL}/getApiLimit`
    )
    const limits = response.data
    setTotalLimit(limits.maxMessagesPerMinute)
    setUsedLimit(limits.messageCount)
    setPercentageUsed((limits.messageCount / limits.maxMessagesPerMinute) * 100)
  }

  // Prepare data for the chart
  const chartData = {
    labels: campaigns.map(item => item.label),
    datasets: [
      {
        label: 'Campaign Performance',
        data: campaigns.map(item => item.value),
        fill: false,
        backgroundColor: 'rgba(136, 132, 216, 0.6)',
        borderColor: 'rgba(136, 132, 216, 1)',
      },
    ],
  }

  return (
    <>
      <Box p='5'>
        <Grid
          templateColumns={{
            base: 'repeat(1, 1fr)',
            md: 'repeat(2, 1fr)',
            lg: 'repeat(4, 1fr)'
          }}
          gap={6}
          mb='6'
        >
          {campaigns.map((item, index) => (
            <GridItem key={index}>
              <Card overflow='hidden' variant='outline' bg='blackAlpha.900'>
                <CardBody>
                  <Stat>
                    <StatLabel color='white'>{item.label}</StatLabel>
                    <StatNumber color='white'>{item.value}</StatNumber>
                    <StatHelpText color='white'>
                      <StatArrow
                        focusable='false'
                        aria-hidden='true'
                        type={item.type}
                      />
                      {item.value}
                    </StatHelpText>
                  </Stat>
                </CardBody>
              </Card>
            </GridItem>
          ))}
        </Grid>

        <Box
          p='5'
          display='flex'
          flexDirection='column'
          alignItems='center'
          borderRadius='md'
          boxShadow='md'
          color='white'
        >
          <HStack spacing={8} width='100%'>
            {/* Left Side: Campaign Performance Graph */}
            <Box
              flex='1'
              display='flex'
              flexDirection='column'
              alignItems='center'
              p='4'
              borderRadius='md'
              boxShadow='md'
              bg='cyan.100'
              color='black'
            >
              <Heading
                size='md'
                mb='4'
                textAlign='center'
                fontWeight='bold'
              >
                Campaign Performance Graph
              </Heading>
              <Line
                data={chartData}
                options={{
                  responsive: true,
                  plugins: {
                    legend: {
                      display: true,
                      position: 'top',
                    },
                  },
                }}
                width={600}
                height={300}
                style={{ margin: 'auto' }}
              />
            </Box>

            {/* Right Side: Message Limits */}
            <Box
              bg={bgColor}
              p={4}
              borderRadius='md'
              boxShadow='md'
              maxWidth='400px'
            >
              <VStack spacing={4} align='stretch'>
                <HStack justifyContent='space-between' align='center' mb={4}>
                  <Heading size='md' color={headingColor}>
                    Message Limits
                  </Heading>
                  <Button size='sm' onClick={fetchLimits}>
                    Refresh
                  </Button>
                </HStack>

                <Box>
                  <Text fontSize='sm' color={textColor} mb={1}>
                    Usage Overview
                  </Text>
                  <Progress
                    value={percentageUsed}
                    size='md'
                    colorScheme={percentageUsed > 80 ? 'red' : 'green'}
                    borderRadius='full'
                  />
                </Box>

                <HStack justifyContent='space-between'>
                  <Stat>
                    <StatLabel color={textColor}>Current Limit</StatLabel>
                    <StatNumber color={headingColor}>{totalLimit}</StatNumber>
                    <StatHelpText color={textColor}>
                      Total available messages
                    </StatHelpText>
                  </Stat>
                  <Stat>
                    <StatLabel color={textColor}>Used</StatLabel>
                    <StatNumber color={headingColor}>{usedLimit}</StatNumber>
                    <StatHelpText color={textColor}>Messages sent</StatHelpText>
                  </Stat>
                  <Stat>
                    <StatLabel color={textColor}>Remaining</StatLabel>
                    <StatNumber color={headingColor}>
                      {totalLimit - usedLimit}
                    </StatNumber>
                    <StatHelpText color={textColor}>
                      Messages available
                    </StatHelpText>
                  </Stat>
                </HStack>
              </VStack>
            </Box>
          </HStack>
        </Box>
      </Box>
    </>
  )
}

export default DashView
