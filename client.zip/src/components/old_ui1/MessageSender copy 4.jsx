import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Input,
  Textarea,
  VStack,
  Text,
  Alert,
  AlertIcon,
  Image,
  Tag,
  TagCloseButton,
  HStack,
  useToast,
  useColorModeValue,
  Wrap,
  WrapItem,
  CloseButton,
} from '@chakra-ui/react';
import axios from 'axios';
import { FaFilePdf, FaFileExcel, FaFileWord, FaImage, FaPaperPlane } from 'react-icons/fa';
import Joyride from 'react-joyride';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

const MessageSender = () => {
  const [message, setMessage] = useState('');
  const [numbers, setNumbers] = useState('');
  const [alert, setAlert] = useState({ status: false, message: '', type: '' });
  const [recipients, setRecipients] = useState([]);
  const [isSending, setIsSending] = useState(false);
  const [showTour, setShowTour] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedFileType, setSelectedFileType] = useState('');
  const [filePreview, setFilePreview] = useState(null); // New state for file preview

  const toast = useToast();

  useEffect(() => {
    const checkFirstVisit = () => {
      const hasVisited = localStorage.getItem('hasVisitedBefore');
      if (hasVisited === null) {
        setShowTour(true);
        localStorage.setItem('hasVisitedBefore', 'true');
      }
    };
    checkFirstVisit();
  }, []);

  const handleJoyrideCallback = (data) => {
    const { status } = data;
    if (status === 'finished' || status === 'skipped') {
      setShowTour(false);
      localStorage.setItem('hasVisitedBefore', 'true');
    }
  };

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.600');
  const textColor = useColorModeValue('gray.800', 'white');
  const inputBgColor = useColorModeValue('gray.50', 'gray.700');

  const steps = [
    {
      placement: 'center',
      target: 'body',
      content: <h2><b>Welcome to the WhatsApp Automation Dashboard!</b></h2>
    },
    // Add more steps as needed
  ];

  const sendMessage = async (type) => {
    if (recipients.length === 0 || (!message && type === 'text') || (type === 'image' && !imageFile)) {
      setAlert({
        status: true,
        message: 'Please enter a message and at least one recipient number.',
        type: 'error',
        duration: 3000,
        isClosable: true
      });
      return;
    }

    setIsSending(true);

    for (const number of recipients) {
      try {
        let response;
        const currentTime = new Date();
        const newMessage = {
          date: currentTime.toLocaleDateString(),
          time: currentTime.toLocaleTimeString(),
          message,
          recipient: number,
          type,
          status: 'sent',
        };

        if (type === 'text') {
          response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/send?message=${encodeURIComponent(message)}&number=${number}`);
        } else if (type === 'image' && imageFile) {
          const reader = new FileReader();
          reader.onloadend = async () => {
            const base64Image = reader.result;
            response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/sendImage`, {
              base64Image,
              number,
              fileName: imageFile.name,
              caption: message,
            });
            handleResponse(response, number);
          };
          reader.readAsDataURL(imageFile);
          continue;
        } else if (selectedFileType && selectedFile) {
          // API call for PDF, Excel, Word
          const formData = new FormData();
          formData.append('file', selectedFile);
          formData.append('number', number);

          response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/send${selectedFileType}`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          });
        }

        handleResponse(response, number);

        if (response.data.success === true) {
          newMessage.status = 'sent';
        } else {
          newMessage.status = 'failed';
        }

        await axios.post(`${import.meta.env.VITE_APP_API_URL}/saveMessage`, newMessage);

      } catch (error) {
        toast({
          title: 'Error',
          description: `Failed to send message to ${number}: ${error.message}`,
          status: 'error',
          duration: 3000,
          isClosable: true
        });
      }

      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    setIsSending(false);
    setImageFile(null);
    setImagePreview(null);
    setSelectedFile(null);
    setSelectedFileType('');
    setFilePreview(null); // Reset file preview
    setMessage('');
    setNumbers('');
    setRecipients([]);
  };

  const handleResponse = (response, number) => {
    if (response.data.success === true) {
      toast({
        title: 'Message Sent',
        description: `Message sent successfully to ${number}`,
        status: 'success',
        duration: 3000,
        isClosable: true
      });
    } else {
      toast({
        title: 'Invalid Number',
        description: `Failed to send message to ${number}: The number does not exist.`,
        status: 'error',
        duration: 3000,
        isClosable: true
      });
    }
  };

  const handleFileChange = (e, type) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setSelectedFileType(type);
      toast({
        title: `${type.toUpperCase()} File Selected`,
        description: `${file.name} selected for sending.`,
        status: 'info',
        duration: 2000,
        isClosable: true
      });

      // Set file preview based on type
      if (type === 'image') {
        const reader = new FileReader();
        reader.onloadend = () => {
          setImagePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(file.name); // For other file types, just show the file name
      }
    }
  };

  return (
    <Box borderWidth={1} borderRadius="md" p={4} boxShadow="md" bg={bgColor} borderColor={borderColor}>
      {showTour && <Joyride steps={steps} run={showTour} continuous callback={handleJoyrideCallback} />}
      
      <Text fontSize="xl" fontWeight="bold" mb={4} color={textColor}>Send WhatsApp Message</Text>

      {alert.status && (
        <Alert status={alert.type} mb={4}>
          <AlertIcon />
          {alert.message}
          <CloseButton position="absolute" right="8px" top="8px" onClick={() => setAlert({ status: false, message: '', type: '' })} />
          </Alert>
      )}

      <Textarea
        placeholder="Enter message..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        mb={3}
        rows={4}
        bg={inputBgColor}
        borderColor={borderColor}
      />

      <Input
        type="text"
        placeholder="Enter numbers"
        value={numbers}
        onChange={(e) => setNumbers(e.target.value)}
        mb={3}
        bg={inputBgColor}
        borderColor={borderColor}
      />

      {recipients.map((num, index) => (
        <Tag key={index} size="md" colorScheme="blue" borderRadius="full" mb={2}>
          {num}
          <TagCloseButton onClick={() => setRecipients(recipients.filter((n) => n !== num))} />
        </Tag>
      ))}

      {/* File Upload Section */}
      <Wrap spacing={4} mb={4}>
        <WrapItem>
          <Button
            leftIcon={<FaImage />}
            colorScheme="blue"
            as="label"
            cursor="pointer"
            htmlFor="image-input"
          >
            Image
          </Button>
          <Input id="image-input" type="file" accept="image/*" display="none" onChange={(e) => handleFileChange(e, 'image')} />
        </WrapItem>
        <WrapItem>
          <Button
            leftIcon={<FaFilePdf />}
            colorScheme="red"
            as="label"
            cursor="pointer"
            htmlFor="pdf-input"
          >
            PDF
          </Button>
          <Input id="pdf-input" type="file" accept=".pdf" display="none" onChange={(e) => handleFileChange(e, 'pdf')} />
        </WrapItem>
        <WrapItem>
          <Button
            leftIcon={<FaFileExcel />}
            colorScheme="green"
            as="label"
            cursor="pointer"
            htmlFor="excel-input"
          >
            Excel
          </Button>
          <Input id="excel-input" type="file" accept=".xls,.xlsx" display="none" onChange={(e) => handleFileChange(e, 'excel')} />
        </WrapItem>
        <WrapItem>
          <Button
            leftIcon={<FaFileWord />}
            colorScheme="blue"
            as="label"
            cursor="pointer"
            htmlFor="doc-input"
          >
            Doc
          </Button>
          <Input id="doc-input" type="file" accept=".doc,.docx" display="none" onChange={(e) => handleFileChange(e, 'doc')} />
        </WrapItem>
      </Wrap>

      {/* Preview Section */}
      {imagePreview && (
        <Box mb={4}>
          <Text fontWeight="bold">Image Preview:</Text>
          <Image src={imagePreview} alt="Image Preview" maxH="200px" />
        </Box>
      )}

      {filePreview && (
        <Box mb={4}>
          <Text fontWeight="bold">File Selected:</Text>
          <Text>{filePreview}</Text>
        </Box>
      )}

      <Button
        leftIcon={<FaPaperPlane />}
        colorScheme="teal"
        onClick={() => sendMessage('text')}
        isDisabled={isSending}
        isLoading={isSending}
        loadingText="Sending"
      >
        Send Message
      </Button>
    </Box>
  );
};

export default MessageSender;
