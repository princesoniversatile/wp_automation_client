import React, { useState, useEffect } from 'react';
import {
  Box,
  Heading,
  useColorModeValue,
  Spinner,
  Text,
  Badge,
  HStack,
  Button,
  VStack,
  Container,
  useToast,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Tag,
  Input,
  Flex,
  IconButton,
  Tooltip,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
} from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon, DownloadIcon, SearchIcon } from '@chakra-ui/icons';
import axios from 'axios';
import * as XLSX from 'xlsx';

const MessageHistory = () => {
  const [campaigns, setCampaigns] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  const cardBgColor = useColorModeValue('white', 'gray.700');
  const textColor = useColorModeValue('gray.800', 'gray.100');
  const borderColor = useColorModeValue('gray.200', 'gray.600');

  const toast = useToast();

  useEffect(() => {
    fetchMessageHistory();
  }, []);

  const fetchMessageHistory = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getMessageHistory`);
      if (response.data.success) {
        setCampaigns(response.data.messages);
      } else {
        throw new Error('Failed to fetch message history');
      }
    } catch (error) {
      console.error('Error fetching message history:', error);
      setError('Failed to load message history. Please try again later.');
      toast({
        title: "Error",
        description: "Failed to load message history. Please try again later.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const exportToExcel = (campaignName, messages) => {
    const worksheet = XLSX.utils.json_to_sheet(messages.map(item => ({
      'Campaign Name': campaignName,
      'Sent On': item.date,
      'Sent At': item.time,
      'Recipient': item.recipient,
      'Message': item.message,
      'Status': item.status,
      'Type': item.type
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Message History');
    XLSX.writeFile(workbook, `${campaignName}_message_history.xlsx`);

    toast({
      title: "Export Successful",
      description: `Message history for ${campaignName} has been exported to Excel.`,
      status: "success",
      duration: 3000,
      isClosable: true,
    });
  };

  const filteredCampaigns = Object.entries(campaigns).filter(([campaignName]) =>
    campaignName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <Box textAlign="center" mt={10}>
        <Spinner size="xl" color="teal.500" />
        <Text mt={4} color={textColor}>Loading message history...</Text>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" mt={10}>
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Container maxW="container.xl">
      <VStack align="stretch">
        <Box
          bg={cardBgColor}
          p={4}
          borderRadius="lg"
          boxShadow="xl"
          borderWidth="1px"
          borderColor={borderColor}
        >
          <VStack spacing={3} align="stretch">
            <Flex justifyContent="space-between" alignItems="center">
              <Heading as="h2" size="lg" color={textColor}>
                <HStack spacing={2} alignItems="center">
                  <Text fontSize="xl" fontWeight="bold" color="blue.600">
                    Communication History Insights
                  </Text>
                  <Badge colorScheme="blue" fontSize="sm" variant="solid">
                    Beta
                  </Badge>
                </HStack>
              </Heading>
            </Flex>
            
            <Flex>
              <Input
                placeholder="Search campaigns..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                mr={2}
              />
              <IconButton icon={<SearchIcon />} aria-label="Search" />
            </Flex>

            <Accordion allowMultiple>
              {filteredCampaigns.map(([campaignName, messages]) => (
                <AccordionItem key={campaignName}>
                  <h2>
                    <AccordionButton>
                      <Box flex="1" textAlign="left">
                        {campaignName} ({messages.length} messages)
                      </Box>
                      <AccordionIcon />
                    </AccordionButton>
                  </h2>
                  <AccordionPanel pb={4}>
                    <Flex justifyContent="flex-end" mb={2}>
                      <Tooltip label={`Export ${campaignName} to Excel`} bg="green.300" color="white">
                        <Button 
                          leftIcon={<DownloadIcon />} 
                          onClick={() => exportToExcel(campaignName, messages)} 
                          size="sm"
                        >
                          Export Campaign
                        </Button>
                      </Tooltip>
                    </Flex>
                    <Box overflowX="auto">
                      <Table variant="simple" size="sm">
                        <Thead>
                          <Tr>
                            <Th>Sent On</Th>
                            <Th>Recipient</Th>
                            <Th>Message</Th>
                            <Th>Status</Th>
                            <Th>Type</Th>
                          </Tr>
                        </Thead>
                        <Tbody>
                          {messages.map((message) => (
                            <Tr key={message._id}>
                              <Td>{message.date} {message.time}</Td>
                              <Td>{message.recipient}</Td>
                              <Td>{message.message.length > 50 ? `${message.message.substring(0, 50)}...` : message.message}</Td>
                              <Td>
                                <Tag
                                  colorScheme={message.status === 'sent' ? 'green' : message.status === 'failed' ? 'red' : 'blue'}
                                >
                                  {message.status}
                                </Tag>
                              </Td>
                              <Td>{message.type}</Td>
                            </Tr>
                          ))}
                        </Tbody>
                      </Table>
                    </Box>
                  </AccordionPanel>
                </AccordionItem>
              ))}
            </Accordion>
          </VStack>
        </Box>
      </VStack>
    </Container>
  );
};

export default MessageHistory;