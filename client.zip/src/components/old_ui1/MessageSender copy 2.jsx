import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  Input,
  Textarea,
  VStack,
  Text,
  Alert,
  AlertIcon,
  Image,
  Tag,
  TagCloseButton,
  TagLabel,
  Wrap,
  WrapItem,
  useColorModeValue,
  useToast,
  HStack
} from '@chakra-ui/react'
import axios from 'axios'
import Joyride from 'react-joyride'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver';

const MessageSender = () => {
  const [message, setMessage] = useState('')
  const [numbers, setNumbers] = useState('')
  const [alert, setAlert] = useState({ status: false, message: '', type: '' })
  const [recipients, setRecipients] = useState([])
  const [isSending, setIsSending] = useState(false)
  const [messageHistory, setMessageHistory] = useState([])
  
  const [showTour, setShowTour] = useState(false);

  const [imageFile, setImageFile] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)

  const toast = useToast()

  useEffect(() => {
    const checkFirstVisit = () => {
      const hasVisited = localStorage.getItem('hasVisitedBefore');
      if (hasVisited === null) {
        setShowTour(true);
        localStorage.setItem('hasVisitedBefore', 'true');
      }
    };

    checkFirstVisit();
  }, []);

  const handleJoyrideCallback = (data) => {
    const { status } = data;
    if (status === 'finished' || status === 'skipped') {
      setShowTour(false);
      localStorage.setItem('hasVisitedBefore', 'true');
    }
  };

  const bgColor = useColorModeValue('white', 'gray.800')
  const borderColor = useColorModeValue('gray.200', 'gray.600')
  const textColor = useColorModeValue('gray.800', 'white')
  const inputBgColor = useColorModeValue('gray.50', 'gray.700')

  const steps = [
    {
      placement: "center",
      target: "body",
      content: <h2><b>Welcome to the WhatsApp Automation Dashboard!</b></h2>
    },
    {
      target: '.message-input',
      content: 'Enter your message in this field.',
      placement: 'top'
    },
    {
      target: '.number-input',
      content:
        <p>Input the recipient number(s) here.<br/> Here you can add multiple numbers by separating them with commas. For example: 9876543210, 9876543211, 9876543212</p>,
      placement: 'top'
    },
    {
      target: '.image-input',
      content: <p><b>Tap here to select an image</b> <br/> (Allowed Formats: jpg, png, jpeg, webp ) </p>,
      placement: 'top'
    },
    {
      target: '.send-text',
      content: 'Click this button to send your message to all Recipients !!',
      placement: 'top'
    },
    {
      target: '.send-multimedia',
      content: 'Click this button to send your message along with an image to all Recipients !!',
      placement: 'top'
    }
  ]

  const handleResponse = (response, number) => {
    if (response.data.success === true) {
      toast({
        title: 'Message Sent',
        description: `Message sent successfully to ${number}`,
        status: 'success',
        duration: 3000,
        isClosable: true
      })
    } else if (response.data.error === 'The group number does not exist on your chat list, or it does not exist at all!') {
      toast({
        title: 'Invalid Number',
        description: `Failed to send message to ${number}: The number does not exist.`,
        status: 'error',
        duration: 3000,
        isClosable: true
      })
    } else {
      throw new Error('Unexpected response or failure')
    }
  }

  const saveToExcel = (newMessage) => {
    const updatedHistory = [...messageHistory, newMessage].sort((a, b) => {
      const dateTimeA = new Date(`${a.date} ${a.time}`);
      const dateTimeB = new Date(`${b.date} ${b.time}`);
      return dateTimeB - dateTimeA;
    });

    setMessageHistory(updatedHistory);

    const worksheet = XLSX.utils.json_to_sheet(updatedHistory);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Message History");

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    saveAs(data, 'public/exports/WhatsApp_Message_History.xlsx');
  };

  const sendMessage = async (type) => {
    if (recipients.length === 0 || (!message && type === 'text') || (type === 'image' && !imageFile)) {
      setAlert({
        status: true,
        message: 'Please enter a message and at least one recipient number.',
        type: 'error',
        duration: 3000,
        isClosable: true
      })
      return
    }
  
    setIsSending(true)
  
    for (const number of recipients) {
      try {
        let response
        const currentTime = new Date()
        const newMessage = {
          date: currentTime.toLocaleDateString(),
          time: currentTime.toLocaleTimeString(),
          message: message,
          recipient: number,
          type: type,
          status: 'sent' // Default status
        };

        if (type === 'text') {
          response = await axios.get(
            `http://192.168.29.100:4001/send?message=${encodeURIComponent(
              message
            )}&number=${number}`
          )
        } else if (type === 'image' && imageFile) {
          const reader = new FileReader()
          reader.onloadend = async () => {
            const base64Image = reader.result
            response = await axios.post(
              'http://192.168.29.100:4001/sendImage',
              {
                base64Image: base64Image,
                number: number,
                fileName: imageFile.name,
                caption: message
              }
            )
            handleResponse(response, number)
          }
          reader.readAsDataURL(imageFile)
          continue;
        }
  
        handleResponse(response, number)

        // Update status based on the response
        if (response.data.success === true) {
          newMessage.status = 'sent'
        } else {
          newMessage.status = 'failed'
        }

        // Save message to database
        await axios.post('http://192.168.29.100:4001/saveMessage', newMessage);

      } catch (error) {
        toast({
          title: 'Error',
          description: `Failed to send message to ${number}: ${error.message}`,
          status: 'error',
          duration: 3000,
          isClosable: true
        })
        
        // Save failed message to database
        const failedMessage = {
          date: new Date().toLocaleDateString(),
          time: new Date().toLocaleTimeString(),
          message: message,
          recipient: number,
          type: type,
          status: 'failed'
        };
        await axios.post('http://192.168.29.100:4001/saveMessage', failedMessage);
      }
  
      await new Promise(resolve => setTimeout(resolve, 2000))
    }
  
    setIsSending(false)
  
    setImageFile(null)
    setImagePreview(null)
    setMessage('')
    setNumbers('')
    setRecipients([])

    // Fetch updated message history
    try {
      const response = await axios.get('http://192.168.29.100:4001/getMessageHistory');
      if (response.data.success) {
        setMessageHistory(response.data.messages);
      }
    } catch (error) {
      console.error('Failed to fetch message history:', error);
    }
  }


  const addRecipient = () => {
    if (numbers) {
      const newNumbers = numbers
        .split(',')
        .map(num => num.trim())
        .filter(num => validateNumber(num) && !recipients.includes(num))
      if (newNumbers.length > 0) {
        setRecipients(prev => [...prev, ...newNumbers])
        setNumbers('')
      } else {
        setAlert({
          status: true,
          message: 'The number is not valid or already added.',
          type: 'warning',
          duration: 3000,
          isClosable: true
        })
      }
    }
  }

  const handleNumberInput = e => {
    const inputValue = e.target.value
    setNumbers(inputValue)

    if (inputValue.endsWith(',')) {
      addRecipient()
    }
  }

  const validateNumber = num => {
    const indianNumberPattern = /^[6-9]\d{9}$/
    if (!indianNumberPattern.test(num)) {
      setAlert({
        status: true,
        message: `Invalid number: ${num}. It should be 10 digits and start with 6-9.`,
        type: 'error',
        duration: 3000,
        isClosable: true
      })
      return false
    }
    return true
  }

  const removeRecipient = numToRemove => {
    setRecipients(recipients.filter(num => num !== numToRemove))
  }

  const handleImageChange = e => {
    const file = e.target.files[0]
    if (file) {
      if (!file.type.startsWith('image/')) {
        setAlert({
          status: true,
          message: 'Please select a valid image file.',
          type: 'error',
          duration: 3000,
          isClosable: true
        })
        return
      }

      if (file.size > 5 * 1024 * 1024) {
        setAlert({
          status: true,
          message: 'Image file size should be less than 5MB.',
          type: 'error',
          duration: 3000,
          isClosable: true
        })
        return
      }

      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => setImagePreview(reader.result)
      reader.onerror = () => {
        setAlert({
          status: true,
          message: 'Error reading the image file.',
          type: 'error',
          duration: 3000,
          isClosable: true
        })
      }
      reader.readAsDataURL(file)
    }
  }

  

  return (
    <Box borderWidth={1} borderRadius="md" p={4} boxShadow="md" bg={bgColor} borderColor={borderColor}>
    {showTour && <Joyride steps={steps} run={showTour} continuous callback={handleJoyrideCallback} />}
    
    <Text fontSize="xl" fontWeight="bold" mb={4} color={textColor}>Send WhatsApp Message</Text>
  
    {alert.status && (
      <Alert status={alert.type} mb={4}>
        <AlertIcon />
        {alert.message}
      </Alert>
    )}
  
    <Textarea
      placeholder="Enter message..."
      value={message}
      onChange={e => setMessage(e.target.value)}
      mb={3}
      rows={4}
      bg={inputBgColor}
      borderColor={borderColor}
    />
  
    <Input
      type="text"
      placeholder="Enter numbers"
      value={numbers}
      onChange={handleNumberInput}
      onKeyDown={e => {
        if (!/^[0-9,]*$/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Control' && e.key !== 'c' && e.key !== 'v' && e.key !== 'a' && e.key !== 'Delete' && e.key !== 'Enter' &&  e.key!=='ArrowLeft' && e.key!=='ArrowRight') {
            e.preventDefault()
          }
          // if (e.target.value.replace(/[^0-9]/g, '').length === 10) {
          //   addRecipient();
          // }
        if (e.key === 'Enter') addRecipient();
      }}
      mb={3}
      bg={inputBgColor}
      borderColor={borderColor}
    />
  
    {recipients.map((num, index) => (
      <Tag key={index} size="md" colorScheme="blue" borderRadius="full" mb={2}>
        {num}
        <TagCloseButton onClick={() => removeRecipient(num)} />
      </Tag>
    ))}
  
    <Input type="file" accept="image/*" onChange={handleImageChange} mb={3} />
  
    {imagePreview && (
      <Box mb={3}>
        <Image src={imagePreview} alt="Image" maxHeight="150px" />
        <Button onClick={() => { setImagePreview(null); setImageFile(null); }} colorScheme="red" size="sm">
          Remove
        </Button>
      </Box>
    )}
  
    <HStack spacing={2} width="100%">
      <Button colorScheme="blue" onClick={() => sendMessage('text')} isLoading={isSending} size="md" flex={1}>
        Send Text
      </Button>
      <Button colorScheme="blue" onClick={() => sendMessage('image')} isDisabled={!imageFile || isSending} size="md" flex={1}>
        Send Image
      </Button>
    </HStack>
  </Box>
  
  
  )
}

export default MessageSender
