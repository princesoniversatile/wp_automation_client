import React, { useState, useEffect } from 'react'
import axios from 'axios'

import {
  Box,
  Grid,
  GridItem,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  TableContainer,
  Table,
  Thead,
  Tr,
  Th,
  Tbody,
  Td,
  Tfoot,
  VStack,
  HStack,
  Heading,
  Text,
  Progress,
  Button,
  useColorModeValue
} from '@chakra-ui/react'


import MessageLimits from './MessageLimits'

const DashView = () => {
  const [messageBalance, setMessageBalance] = useState(0)
  const [totalCampaigns, setTotalCampaigns] = useState(0)
  const [todayCampaigns, setTodayCampaigns] = useState(0)
  const [totalSentMessages, setTotalSentMessages] = useState(0)
  const [percentageUsed, setPercentageUsed] = useState(0)
  const [totalLimit, setTotalLimit] = useState(0)
  const [usedLimit, setUsedLimit] = useState(0)
  const [remainingLimit, setRemainingLimit] = useState(0)

  


  useEffect(() => {
    console.log('hi')
    fetchStatistics();
    fetchLimits()
  }, []); 

  console.log(messageBalance, totalCampaigns, todayCampaigns, totalSentMessages)

  const [campaigns, setCampaigns] = useState([
    { label: 'Available Message Balance', value: messageBalance, type: 'increase' },
    { label: 'Total Campaigns', value: totalCampaigns, type: 'increase' },
    { label: 'Today Campaigns', value: todayCampaigns, type: 'decrease' },
    { label: 'Total Sent Messages', value: totalSentMessages, type: 'increase' }
  ])

  const bgColor = useColorModeValue('gray.700', 'gray.700');
  const headingColor = useColorModeValue('gray.200', 'gray.200');
  const textColor = useColorModeValue('gray.200', 'gray.200');
  

  const fetchStatistics = async () => {
    const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/dashboard`);
    const statistics = response.data.statistics
    console.log(statistics)
    setMessageBalance(statistics.availableMessageBalance)
    setTotalCampaigns(statistics.totalCampaigns)
    setTodayCampaigns(statistics.todayCampaigns)
    setTotalSentMessages(statistics.totalSentMessages)

    setCampaigns([
      { label: 'Available Message Balance', value: statistics.availableMessageBalance, type: 'increase' },
      { label: 'Total Campaigns', value: statistics.totalCampaigns, type: 'increase' },
      { label: 'Today Campaigns', value: statistics.todayCampaigns, type: 'decrease' },
      { label: 'Total Sent Messages', value: statistics.totalSentMessages, type: 'increase' }
    ]);
  };

  const fetchLimits = async () => {
    const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getApiLimit`);
    const limits = response.data;
    setTotalLimit(limits.maxMessagesPerMinute);
    setUsedLimit(limits.messageCount);
    setPercentageUsed((limits.messageCount / limits.maxMessagesPerMinute) * 100);
  };



  return (
    <>
      <Box p='5' bis_skin_checked='1'>
        <Grid
          templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }}
          gap={6}
          mb='6'
          bis_skin_checked='1'
        >
          {campaigns.map((item, index) => (
            <GridItem key={index} bis_skin_checked='1'>
              <Card
                overflow='hidden'
                variant='outline'
                bg='blackAlpha.900'
                bis_skin_checked='1'
              >
                <CardBody bis_skin_checked='1'>
                  <Stat bis_skin_checked='1'>
                    <StatLabel color='white'>{item.label}</StatLabel>
                    <StatNumber color='white'>{item.value}</StatNumber>
                    <StatHelpText color='white'>
                      <StatArrow
                        focusable='false'
                        aria-hidden='true'
                        type={item.type}
                      ></StatArrow>
                      {item.value}
                    </StatHelpText>
                  </Stat>
                </CardBody>
              </Card>
            </GridItem>
          ))}
        </Grid>
        <Grid templateColumns={{ base: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)', lg: 'repeat(12,1fr)' }} gap={6} bis_skin_checked='1'>
          <GridItem
            colSpan={{ base: 12, lg: 4 }}
            bis_skin_checked='1'
          ></GridItem>
          <GridItem
            colSpan={{ base: 12, lg: 8 }}
            bis_skin_checked='1'
          ></GridItem>
        </Grid>
      </Box>

    <Box p='5' bis_skin_checked='1'>
      <Heading size="md" color={headingColor} mb='4'>
        Campaign Performance Graph
      </Heading>
      <LineChart
        data={campaigns.map(item => ({
          label: item.label,
          value: item.value,
          type: item.type,
        }))}
        labels={['Available Message Balance', 'Total Campaigns', 'Today Campaigns', 'Total Sent Messages']}
        colors={['blue', 'green', 'red', 'yellow']}
      />
    </Box>

    <Box
      bg={bgColor}
      p={4}
      borderRadius="md"
      boxShadow="md"
      maxWidth="400px"
      margin="auto"
    >
      <VStack spacing={2} align="stretch">
        <HStack justifyContent="space-between" align="center">
          <Heading size="md" color={headingColor}>
            Message Limits
          </Heading>
          <Button size="sm" onClick={fetchLimits}>Refresh</Button>
        </HStack>
        
        <Box>
          <Text fontSize="sm" color={textColor} mb={1}>
            Usage Overview
          </Text>
          <Progress
            value={percentageUsed}
            size="md"
            colorScheme={percentageUsed > 80 ? "red" : "green"}
            borderRadius="full"
          />
        </Box>

        <Stat>
          <StatLabel color={textColor}>Current Limit</StatLabel>
          <StatNumber color={headingColor}>{totalLimit}</StatNumber>
          <StatHelpText color={textColor}>Total available messages</StatHelpText>
        </Stat>

        <Stat>
          <StatLabel color={textColor}>Used</StatLabel>
          <StatNumber color={headingColor}>{usedLimit}</StatNumber>
          <StatHelpText color={textColor}>Messages sent</StatHelpText>
        </Stat>

        <Stat>
          <StatLabel color={textColor}>Remaining</StatLabel>
          <StatNumber color={headingColor}>{remainingLimit}</StatNumber>
          <StatHelpText color={textColor}>Messages available</StatHelpText>
        </Stat>
      </VStack>
    </Box>
      
    </>
  )
}

export default DashView
