// import { HStack } from "@chakra-ui/react";
// import { useState } from "react";
import Navbar from "./Nav";
import MessageSender from "./MessageSender";
import GroupManager from "./GroupManager";
import MessageHistory from "./MessageHistory";

import { Box, Flex, HStack, Text, Button, useBreakpointValue, Image } from "@chakra-ui/react";
import { useState } from "react";
import logo from '../assets/nsv.svg';

const Dashboard = () => {
  const [activeButton, setActiveButton] = useState('message');

  const handleButtonClick = (component) => {
    setActiveComponent(component);
    setActiveButton(component);
  };

  const isMobile = useBreakpointValue({ base: true, md: false });
  const [activeComponent, setActiveComponent] = useState("message"); // Default to MessageSender

  return (
    <>
          <Box 
      bg="#2C3E50" 
      p={6} 
      boxShadow="0 4px 6px rgba(0, 0, 0, 0.1)" 
      color="white"
    >
      <Flex 
        direction={isMobile ? "column" : "row"} 
        justifyContent="space-between" 
        alignItems={isMobile ? "center" : "flex-start"}
        spacing={4}
      >
        <HStack spacing={3} mb={isMobile ? 4 : 0}>
          <Image src={logo}  alt="logo" width="50px" height="50px"  filter="invert(1)"  />
          <Text fontSize={["xl", "2xl"]} fontWeight="bold" >
            WhatsApp Automation Dashboard
          </Text>
        </HStack>
        <HStack spacing={5} justifyContent={isMobile ? "center" : "flex-end"}>
          <Button
            variant={activeButton === 'message' ? "solid" : "ghost"}
            colorScheme="whiteAlpha"
            onClick={() => handleButtonClick('message')}
            _hover={{ bg: "whiteAlpha.200" }}
            bg={activeButton === 'message' ? "whiteAlpha.200" : "transparent"}
            size={isMobile ? "sm" : "md"}
          >
            Send Message
          </Button>
          <Button
            variant={activeButton === 'group' ? "solid" : "ghost"}
            colorScheme="whiteAlpha"
            onClick={() => handleButtonClick('group')}
            _hover={{ bg: "whiteAlpha.200" }}
            bg={activeButton === 'group' ? "whiteAlpha.200" : "transparent"}
            size={isMobile ? "sm" : "md"}
          >
            Manage Groups
          </Button>
          <Button
            variant={activeButton === 'history' ? "solid" : "ghost"}
            colorScheme="whiteAlpha"
            onClick={() => handleButtonClick('history')}
            _hover={{ bg: "whiteAlpha.200" }}
            bg={activeButton === 'history' ? "whiteAlpha.200" : "transparent"}
            size={isMobile ? "sm" : "md"}
          >
            Message History
          </Button>
        </HStack>
      </Flex>
    </Box>
      <HStack padding={8} justifyContent="center">
        {activeComponent === "message" ? (
          <MessageSender />
        ) : activeComponent === "group" ? (
          <GroupManager />
        ) : (
          <MessageHistory />
        )}
      </HStack>
    </>
  );
};

export default Dashboard;
