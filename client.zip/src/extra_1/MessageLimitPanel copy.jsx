
import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  GridItem,
  Heading,
  Input,
  Text,
  useToast,
  VStack,
  HStack,
  Image,
  Alert,
  AlertIcon,
  useColorModeValue,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Progress,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  Select
} from '@chakra-ui/react';

import { RepeatIcon } from '@chakra-ui/icons';
import axios from 'axios';

const MessageLimitPanel = () => {

  const [messageLimit, setMessageLimit] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [currentLimit, setCurrentLimit] = useState({});
  const [totalLimit, setTotalLimit] = useState(0);
  const [usedLimit, setUsedLimit] = useState(0);
  // const [remainingLimit, setRemainingLimit] = useState(0);
  const [percentageUsed, setPercentageUsed] = useState(0);
  const [selectedUser, setSelectedUser] = useState('');
  const [users, setUsers] = useState([]);
  const [balanceType, setBalanceType] = useState('');



  const toast = useToast();

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');
  const textColor = useColorModeValue('gray.700', 'gray.200');

  const headingColor = useColorModeValue('gray.700', 'gray.200');

  useEffect(() => {
  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getAllUsers`);
      const apiUsers = response.data.map((user) => ({
        id: user._id,
        name: user.username,
        email: user.emailId,
        type: user.type,
        creditLimit: user.creditLimit,
        companyName: user.companyName || 'N/A',
        contactPerson: user.contactPerson || 'N/A',
      }));
      setUsers(apiUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  fetchUsers();
}, []);

console.log(`selectedUser: ${selectedUser}`);
console.log(`users: ${users}`);

useEffect(async ()=>{
  const setLimit=await axios.post(`${import.meta.env.VITE_APP_API_URL}/updateCreditLimit`, {
    emailId: selectedUser,
    newCreditLimit: messageLimit
  });
  setCurrentLimit(setLimit.data);
}, []);

  const fetchQrCode = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/qrimage`, {
        responseType: 'blob',
      });
      const imageUrl = URL.createObjectURL(response.data);
      setQrCode(imageUrl);
    } catch (error) {
      setError('QR code not available. Please try again later.');
      toast({
        title: 'Failed to load QR code.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const checkConnectionStatus = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/check-status`);
      setIsConnected(response.data.connected);
    } catch (error) {
      console.error('Error fetching connection status:', error);
      setIsConnected(false);
      toast({
        title: 'Error fetching connection status.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // const fetchCurrentLimit = async () => {
  //   try {
  //     const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getApiLimit`);
  //     setCurrentLimit(response.data);
  //     setTotalLimit(response.data.maxMessagesPerMinute);
  //     setUsedLimit(response.data.messageCount);
  //     // setRemainingLimit(response.data.maxMessagesPerMinute - response.data.messageCount);
  //     setPercentageUsed((response.data.messageCount / response.data.maxMessagesPerMinute) * 100);
  //   } catch (error) {
  //     console.error('Error fetching current limit:', error);
  //     toast({
  //       title: 'Error fetching current limit.',
  //       status: 'error',
  //       duration: 3000,
  //       isClosable: true,
  //     });
  //   }
  // };
  const fetchCurrentLimit = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getApiLimit`);
      setCurrentLimit(response.data);
      setTotalLimit(response.data.maxMessagesPerMinute);
      setUsedLimit(response.data.messageCount);
      // setRemainingLimit(response.data.maxMessagesPerMinute - response.data.messageCount);
      setPercentageUsed((response.data.messageCount / response.data.maxMessagesPerMinute) * 100);
    } catch (error) {
      console.error('Error fetching current limit:', error);
      toast({
        title: 'Error fetching current limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleLimitSubmit = async () => {
    try {
        const response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/updateBalance`, {
        emailId: selectedUser,
        amount: messageLimit,
        type: balanceType
      });
      console.log('Message limit set successfully:', response.data);
      toast({
        title: 'Message limit set successfully!',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error setting message limit:', error);
      toast({
        title: 'Failed to set message limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  useEffect(() => {
    const initialize = async () => {
      await fetchQrCode();
      await checkConnectionStatus();
      await fetchCurrentLimit();
    };
    initialize();
  }, []);

  const handleRefresh = () => {
    setMessageLimit(''); 
    fetchQrCode(); 
    checkConnectionStatus();
    fetchCurrentLimit();
  };

  const handleLimitChange = (event) => {
    setMessageLimit(event.target.value);
  };

  const remainingLimit = currentLimit.maxMessagesPerMinute - currentLimit.messageCount;

  return (
    <Box
      bg={bgColor}
      p={4}
      borderRadius="lg"
      boxShadow="xl"
      maxWidth="1000px"
      margin="auto"
      display="flex"
      flexDirection="column"
      alignItems="center"
    >

      <Button
        leftIcon={<RepeatIcon transform="rotate(180deg)" />}
        colorScheme="blue"
        onClick={handleRefresh}
        width="full"
        mb={6}
      >
        Refresh Data
      </Button>

      <Box width="100%" px={4}>
      <Grid 
        templateColumns="repeat(12, 1fr)" 
        gap={10} 
        mb={6} 
        width="100%"
        justifyContent="space-between"
      >
        <GridItem colSpan={[12, 5, 6]} > 
        {/* 12,5,5 is the breakpoint for the grid. 12 is the default, 5 is the medium, and 5 is the large */}
          <VStack spacing={10} align="center" justifyContent="center">
          <Heading as="h5" size="md" mb={2}>
             CREDIT MANAGEMENT
            </Heading>

            <Select
              placeholder="Select Balance Type"
              value={balanceType}
              onChange={(e) => setBalanceType(e.target.value)}
              mb={2}
              filterOption={(option, search) => option.text.toLowerCase().includes(search.toLowerCase())}
            >
              <option value="creditBalance" icon={<RepeatIcon />} badge>Credit Balance</option>
              <option value="debitBalance" icon={<RepeatIcon />} badge>Debit Balance</option>
            </Select>
            
            <Select
              placeholder="Select User"
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              mb={2}
              filterOption={(option, search) => option.text.toLowerCase().includes(search.toLowerCase())}
            >
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </Select>


           
            <Input
              placeholder="Enter Balance Amount"
              value={messageLimit}
              type="number"
              onChange={handleLimitChange}
              mb={2}
            />
            <Button colorScheme="blue" onClick={handleLimitSubmit} width="full">
               {balanceType === 'creditBalance' ? 'Add Credit' : 'Add Debit'}
            </Button>

            
          </VStack>
        </GridItem>
        
        <GridItem colSpan={[12, 5, 6]}>
          <Box bg={useColorModeValue('gray.100', 'gray.700')} p={4} borderRadius="md" boxShadow="md">
            <Heading as="h6" size="sm" mb={4} textAlign="center" color={textColor} >Usage Overview</Heading>
            <VStack spacing={4} align="stretch" alignContent="stretch" direction="row" >
              
              <Progress
                value={percentageUsed}
                size="lg"
                colorScheme={percentageUsed > 80 ? "red" : "green"}
                borderRadius="full"
              />
              <Stat>
                <StatLabel color={textColor}  style={{fontWeight: 'bold'}} >Total Limit</StatLabel>
                <StatNumber color={headingColor} >{totalLimit}</StatNumber>
                <StatHelpText color={textColor} >Total available messages</StatHelpText>
              </Stat>
              <Stat>
                <StatLabel color={textColor}  style={{fontWeight: 'bold'}} >Used</StatLabel>
                <StatNumber color={headingColor} >{usedLimit}</StatNumber>
                <StatHelpText color={textColor} >Messages sent</StatHelpText>
              </Stat>
              <Stat>
                <StatLabel color={textColor}  style={{fontWeight: 'bold'}} >Remaining</StatLabel>
                <StatNumber color={headingColor} >{remainingLimit}</StatNumber>
                <StatHelpText color={textColor} >Messages available</StatHelpText>
              </Stat>
            </VStack>
          </Box>
        </GridItem>
      </Grid>
    </Box>
    </Box>
  );
};


export default MessageLimitPanel;
