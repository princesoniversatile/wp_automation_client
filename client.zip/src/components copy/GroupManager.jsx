import { RepeatIcon, WarningIcon } from '@chakra-ui/icons'
import {
  Box,
  Button,
  HStack,
  VStack,
  Text,
  Image,
  Spinner,
  Avatar,
  Container,
  useColorModeValue,
  Icon
} from '@chakra-ui/react'
import { useState, useEffect } from 'react'
import Joyride from 'react-joyride'

const GroupManager = () => {
  const [groups, setGroups] = useState([])
  const [selectedGroup, setSelectedGroup] = useState(null)
  const [groupMembers, setGroupMembers] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [runTour, setRunTour] = useState(true)

  const bgColor = useColorModeValue('white', 'gray.800')
  const textColor = useColorModeValue('blue.600', 'gray.100')
  const borderColor = useColorModeValue('gray.200', 'gray.600')

  const fetchGroups = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`${import.meta.env.VITE_APP_API_URL}/groupData`)
      const { data } = await response.json()
      setGroups(data)
    } catch (error) {
      console.error('Error fetching groups:', error)
    }
    setIsLoading(false)
  }

  const fetchGroupMembers = async groupId => {
    setIsLoading(true)
    try {
      const response = await fetch(`http://192.168.29.100:4001/getMembers/${groupId}`)
      const { members } = await response.json()
      setGroupMembers(members)
      setSelectedGroup(groupId)
    } catch (error) {
      console.error('Error fetching group members:', error)
    }
    setIsLoading(false)
  }

  const steps = [
    {
      target: '.fetch-groups-button',
      content: 'Click here to fetch the groups!'
    },
    {
      target: '.group-item',
      content: 'Here are your groups. Click on one to see members!'
    },
    {
      target: '.group-members',
      content: 'This section shows the members of the selected group.'
    }
  ]

  useEffect(() => {
    fetchGroups()
  }, [])

  return (
    <Container maxW='container.xl' bg={bgColor}>
      <VStack align='stretch' spacing={4} py={6}>
        <Box>
          <Text fontSize='2xl' fontWeight='bold' color={textColor} mb={3} >
            Manage WhatsApp Groups
          </Text>
          <Button
            colorScheme='blue'
            className='fetch-groups-button'
            onClick={fetchGroups}
            size='md'
            fontWeight='normal'
          >
            Fetch Groups
          </Button>
        </Box>

        <Joyride
          steps={steps}
          run={runTour}
          continuous={true}
          showProgress={true}
          showSkipButton={true}
          callback={data => {
            if (['finished', 'skipped'].includes(data.status)) {
              setRunTour(false)
            }
          }}
        />

        {isLoading ? (
          <Spinner />
        ) : (
          <HStack alignItems='flex-start' spacing={6} height='330px'>
            <VStack
              spacing={2}
              align='stretch'
              flex={1}
              overflowY='auto'
              maxHeight='100%'
              css={{
                '&::-webkit-scrollbar': { width: '4px' },
                '&::-webkit-scrollbar-thumb': { background: borderColor, borderRadius: '4px' },
                scrollbarWidth: 'thin',
                scrollbarColor: `${borderColor} transparent`
              }}
            >
              {groups.length > 0 ? (
                groups.map(group => (
                  <Box
                    key={group.groupId}
                    p={3}
                    borderWidth={1}
                    borderColor={borderColor}
                    borderRadius='md'
                    cursor='pointer'
                    className='group-item'
                    onClick={() => {
                      try {
                        fetchGroupMembers(group.groupId);
                      } catch (error) {
                        console.error("Error fetching group members:", error);
                        toast({
                          title: "Error",
                          description: "Failed to fetch group members. Please try again.",
                          status: "error",
                          duration: 3000,
                          isClosable: true,
                        });
                      }
                    }}
                    bg={selectedGroup === group.groupId ? 'blue.50' : 'transparent'}
                    _hover={{ bg: 'gray.50' }}
                    transition='all 0.2s'
                  >
                    <HStack spacing={3}>
                      <Image
                        src={group.profileLink || '/av.png'}
                        boxSize='40px'
                        borderRadius='full'
                        alt='Group'
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = '/av.png';
                        }}
                      />
                      <Text fontSize='md' fontWeight='medium'>
                        {group.groupName || 'Unnamed Group'}
                      </Text>
                    </HStack>
                  </Box>
                ))
              ) : (
                <VStack spacing={4} align="center" p={6} borderWidth={1} borderRadius="lg" borderColor="gray.200" bg="gray.50">
                  <Icon as={WarningIcon} w={10} h={10} color="orange.400" />
                  <Text color="gray.600" fontSize="lg" fontWeight="medium" textAlign="center">
                    No groups found
                  </Text>
                  <Text color="gray.500" fontSize="sm" textAlign="center">
                    Make sure you're connected to WhatsApp and try fetching groups again.
                  </Text>
                  <Button
                    leftIcon={<RepeatIcon />}
                    colorScheme="blue"
                    variant="outline"
                    onClick={() => fetchGroups()}
                  >
                    Check WhatsApp Connectivity
                  </Button>
                </VStack>
              )}
            </VStack>

            {selectedGroup && (
              <VStack
                spacing={3}
                align='stretch'
                flex={1}
                borderWidth={1}
                borderColor={borderColor}
                borderRadius='md'
                p={4}
                className='group-members'
                overflowY='auto'
                maxHeight='100%'
                css={{
                  '&::-webkit-scrollbar': { width: '4px' },
                  '&::-webkit-scrollbar-thumb': { background: borderColor, borderRadius: '4px' },
                  scrollbarWidth: 'thin',
                  scrollbarColor: `${borderColor} transparent`
                }}
              >
                <Text fontSize='lg' fontWeight='semibold' color={textColor}>
                  Group Members
                </Text>
                {groupMembers.map(member => (
                  <HStack
                    key={member.memberNumber}
                    spacing={3}
                    p={2}
                    borderRadius='md'
                    _hover={{ bg: 'gray.50' }}
                    transition='all 0.2s'
                  >
                    <Avatar
                      size='sm'
                      name={member.memberName}
                      src={`https://api.dicebear.com/6.x/initials/svg?seed=${member.memberName}`}
                    />
                    <VStack align='start' spacing={0}>
                      <Text fontSize='sm' fontWeight='medium'>
                        {member.memberName}
                      </Text>
                      <Text fontSize='xs' color='gray.500'>
                        {member.memberNumber}
                      </Text>
                    </VStack>
                  </HStack>
                ))}
              </VStack>
            )}
          </HStack>
        )}
      </VStack>
    </Container>
  )
}

export default GroupManager
