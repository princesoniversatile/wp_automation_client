import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  Box,
  Grid,
  GridItem,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  VStack,
  HStack,
  Heading,
  Text,
  Progress,
  Button,
  useColorModeValue,
  Flex
} from '@chakra-ui/react'
import { Line } from 'react-chartjs-2'
import { Chart, registerables } from 'chart.js'
import { RepeatIcon } from '@chakra-ui/icons'

// Register all necessary components
Chart.register(...registerables)

const DashView = () => {
  const [messageBalance, setMessageBalance] = useState(0)
  const [totalCampaigns, setTotalCampaigns] = useState(0)
  const [todayCampaigns, setTodayCampaigns] = useState(0)
  const [totalSentMessages, setTotalSentMessages] = useState(0)
  const [percentageUsed, setPercentageUsed] = useState(0)
  const [totalLimit, setTotalLimit] = useState(0)
  const [usedLimit, setUsedLimit] = useState(0)
  const [campaigns, setCampaigns] = useState([])

  // Modern color scheme
  const cardBg = useColorModeValue('white', 'gray.800')
  const textColor = useColorModeValue('gray.600', 'gray.200')
  const statNumberColor = useColorModeValue('gray.900', 'white')
  const borderColor = useColorModeValue('gray.200', 'gray.700')

  const cardColors = ['blue', 'purple', 'green', 'orange']

  useEffect(() => {
    fetchStatistics()
    fetchLimits()
  }, [])

  const fetchStatistics = async () => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_APP_API_URL}/dashboard`
      )
      const statistics = response.data.statistics
      setMessageBalance(statistics.availableMessageBalance)
      setTotalCampaigns(statistics.totalCampaigns)
      setTodayCampaigns(statistics.todayCampaigns)
      setTotalSentMessages(statistics.totalSentMessages)

      setCampaigns([
        {
          label: 'Available Message Balance',
          value: statistics.availableMessageBalance,
          type: 'increase'
        },
        {
          label: 'Total Campaigns',
          value: statistics.totalCampaigns,
          type: 'increase'
        },
        {
          label: 'Today Campaigns',
          value: statistics.todayCampaigns,
          type: 'decrease'
        },
        {
          label: 'Total Sent Messages',
          value: statistics.totalSentMessages,
          type: 'increase'
        }
      ])
    } catch (error) {
      console.error('Error fetching statistics:', error)
    }
  }

  const fetchLimits = async () => {
    try {
      const response = await axios.get(
        `${import.meta.env.VITE_APP_API_URL}/getApiLimit`
      )
      const limits = response.data
      setTotalLimit(limits.maxMessagesPerMinute)
      setUsedLimit(limits.messageCount)
      setPercentageUsed((limits.messageCount / limits.maxMessagesPerMinute) * 100)
    } catch (error) {
      console.error('Error fetching limits:', error)
    }
  }

  // Prepare data for the chart
  const chartData = {
    labels: campaigns.map(item => item.label),
    datasets: [
      {
        label: 'Campaign Performance',
        data: campaigns.map(item => item.value),
        fill: false,
        backgroundColor: 'rgba(136, 132, 216, 0.6)',
        borderColor: 'rgba(136, 132, 216, 1)',
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: borderColor,
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  }

  return (
    <Box p={6} bg={useColorModeValue('gray.50', 'gray.900')}>
      <Grid
        templateColumns={{
          base: 'repeat(1, 1fr)',
          md: 'repeat(2, 1fr)',
          lg: 'repeat(4, 1fr)'
        }}
        gap={6}
        mb={8}
      >
        {campaigns.map((item, index) => (
          <GridItem key={index}>
            <Card 
              bg={cardBg} 
              borderColor={borderColor}
              borderWidth="1px"
              boxShadow="sm"
            >
              <CardBody>
                <Stat>
                  <StatLabel color={textColor}>{item.label}</StatLabel>
                  <StatNumber color={statNumberColor} fontSize="2xl">
                    {item.value.toLocaleString()}
                  </StatNumber>
                  <StatHelpText>
                    <StatArrow type={item.type} />
                    {item.type === 'increase' ? '+' : '-'}{Math.floor(Math.random() * 100)}%
                  </StatHelpText>
                </Stat>
                <Progress 
                  value={item.value} 
                  colorScheme={cardColors[index]}
                  size="xs"
                  borderRadius="full"
                />
              </CardBody>
            </Card>
          </GridItem>
        ))}
      </Grid>

      <Grid templateColumns={{ base: '1fr', lg: '1fr 1fr' }} gap={6}>
        {/* Campaign Performance Graph */}
        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px" boxShadow="sm">
          <CardBody>
            <Flex justify="space-between" align="center" mb={4}>
              <Heading size="md" color={statNumberColor}>
                Campaign Performance
              </Heading>
              <Button
                leftIcon={<RepeatIcon />}
                colorScheme="purple"
                variant="ghost"
                size="sm"
                onClick={fetchStatistics}
              >
                Refresh
              </Button>
            </Flex>
            <Box h="220px">
              <Line data={chartData} options={chartOptions} />
            </Box>
          </CardBody>
        </Card>

        {/* Message Limits */}
        <Card bg={cardBg} borderColor={borderColor} borderWidth="1px" boxShadow="sm">
          <CardBody>
            <VStack spacing={5} align="stretch">
              <Flex justify="space-between" align="center">
                <Heading size="md" color={statNumberColor}>
                  Message Limits
                </Heading>
                <Button
                  leftIcon={<RepeatIcon />}
                  colorScheme="purple"
                  variant="ghost"
                  size="sm"
                  onClick={fetchLimits}
                >
                  Refresh
                </Button>
              </Flex>

              <Box>
                <Flex justify="space-between" mb={2}>
                  <Text fontSize="sm" color={textColor}>
                    Usage Overview
                  </Text>
                  <Text fontSize="sm" color={textColor}>
                    {percentageUsed.toFixed(1)}%
                  </Text>
                </Flex>
                <Progress
                  value={percentageUsed}
                  colorScheme={percentageUsed > 80 ? 'red' : 'purple'}
                  size="sm"
                  borderRadius="full"
                />
              </Box>

              <Grid templateColumns="repeat(3, 1fr)" gap={4}>
                <Stat>
                  <StatLabel color={textColor}>Total Limit</StatLabel>
                  <StatNumber color={statNumberColor}>
                    {totalLimit.toLocaleString()}
                  </StatNumber>
                </Stat>
                <Stat>
                  <StatLabel color={textColor}>Used</StatLabel>
                  <StatNumber color={statNumberColor}>
                    {usedLimit.toLocaleString()}
                  </StatNumber>
                </Stat>
                <Stat>
                  <StatLabel color={textColor}>Remaining</StatLabel>
                  <StatNumber color={statNumberColor}>
                    {(totalLimit - usedLimit).toLocaleString()}
                  </StatNumber>
                </Stat>
              </Grid>
            </VStack>
          </CardBody>
        </Card>
      </Grid>
    </Box>
  )
}

export default DashView