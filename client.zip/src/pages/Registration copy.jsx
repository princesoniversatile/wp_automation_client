import React, { useState } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  HStack,
  Text,
  useColorModeValue,
  useToast,
  InputGroup,
  InputRightElement,
} from '@chakra-ui/react';

const Registration = () => {
  const [companyName, setCompanyName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [mobileNo, setMobileNo] = useState('');
  const [whatsappNo, setWhatsappNo] = useState('');
  const [creditLimit, setCreditLimit] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [emailId, setEmailId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const handleRegister = async () => {
    setIsLoading(true);
    try {
      const response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/register`, {
        companyName,
        contactPerson,
        address,
        city,
        state,
        mobileNo,
        whatsappNo,
        creditLimit,
        username,
        password,
        emailId,
      });
      console.log('Registration successful:', response.data);
      toast({
        title: "Registration successful.",
        description: "Your registration has been successful.",
        status: "success",
        duration: 9000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error registering user:', error);
      toast({
        title: "Registration failed.",
        description: "There was an error registering your account.",
        status: "error",
        duration: 9000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Box
      w="full"
      maxW="6xl"
      bg={useColorModeValue('white', 'gray.800')}
      rounded="xl"
      boxShadow="lg"
      p={4}
    //   my={12}
    >
      <Text
        fontSize={{ base: 'lg', md: 'xl' }}
        color={useColorModeValue('gray.700', 'gray.200')}
        mb={2}
        textAlign="center"
        fontWeight="bold"
      >
        User Registration
      </Text>
      <HStack spacing={5} justify="space-between">
      <VStack spacing={1} w="full">
      <FormControl id="companyName">
            <FormLabel>Company Name</FormLabel>
            <Input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
            />
          </FormControl>
          <FormControl id="contactPerson">
            <FormLabel>Contact Person</FormLabel>
            <Input
              type="text"
              value={contactPerson}
              onChange={(e) => setContactPerson(e.target.value)}
            />
          </FormControl>
          <FormControl id="username">
            <FormLabel>Username</FormLabel>
            <Input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </FormControl>
          <FormControl id="password">
            <FormLabel>Password</FormLabel>
            <InputGroup>
              <Input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <InputRightElement width="4.5rem" >
                <Button
                  size="sm"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? 'Hide' : 'Show'}
                </Button>
              </InputRightElement>
            </InputGroup>
          </FormControl>
          <FormControl id="emailId">
            <FormLabel>Email ID</FormLabel>
            <Input
              type="email"
              value={emailId}
              onChange={(e) => setEmailId(e.target.value)}
            />
          </FormControl>
          <FormControl id="creditLimit">
            <FormLabel>Credit Limit</FormLabel>
            <Input
              type="number"
              value={creditLimit}
              onChange={(e) => setCreditLimit(e.target.value)}
            />
          </FormControl>
        </VStack>
        <VStack spacing={1} w="full">
          
          <FormControl id="address">
            <FormLabel>Address</FormLabel>
            <Input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </FormControl>
          <FormControl id="city">
            <FormLabel>City</FormLabel>
            <Input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
            />
          </FormControl>
          <FormControl id="state">
            <FormLabel>State</FormLabel>
            <Input
              type="text"
              value={state}
              onChange={(e) => setState(e.target.value)}
            />
          </FormControl>
          <FormControl id="mobileNo">
            <FormLabel>Mobile No.</FormLabel>
            <Input
              type="number"
              value={mobileNo}
              onChange={(e) => setMobileNo(e.target.value)}
            />
          </FormControl>
          <FormControl id="whatsappNo">
            <FormLabel>Whatsapp No.</FormLabel>
            <Input
              type="number"
              value={whatsappNo}
              onChange={(e) => setWhatsappNo(e.target.value)}
            />
          </FormControl>

          <Button
        colorScheme="blue"
        variant="solid"
        onClick={handleRegister}
        isLoading={isLoading}
        loadingText="Registering"
        mt={1}
      >
        Register
      </Button>
         
        </VStack>
       
      </HStack>
     
    </Box>
  );
};

export default Registration;
