import { useState, useEffect } from "react";
import {
  Box,
  Button,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Input,
  FormControl,
  FormLabel,
  VStack,
  HStack,
  useToast,
} from "@chakra-ui/react";
import axios from 'axios';

const UserTable = ({setActiveComponent}) => {
  const { isOpen: isEditOpen, onOpen: onEditOpen, onClose: onEditClose } = useDisclosure();
  const { isOpen: isAddOpen, onOpen: onAddOpen, onClose: onAddClose } = useDisclosure();
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [newUser, setNewUser] = useState({
    companyName: '',
    contactPerson: '',
    address: '',
    city: '',
    state: '',
    mobileNo: '',
    whatsappNo: '',
    creditLimit: '',
    username: '',
    password: '',
    emailId: '',
  });
  const toast = useToast();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getAllUsers`);
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error fetching users",
        description: "There was an error fetching the user list.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setSelectedUser({ ...selectedUser, [name]: value });
  };

  const handleAddChange = (e) => {
    const { name, value } = e.target;
    setNewUser({ ...newUser, [name]: value });
  };

  const handleEdit = async () => {
    if (!selectedUser) return;
    
    try {
      await axios.put(`${import.meta.env.VITE_APP_API_URL}/updateUser/${selectedUser._id}`, selectedUser);
      setUsers(users.map(user => 
        user._id === selectedUser._id ? selectedUser : user
      ));
      onEditClose();
      toast({
        title: "User updated",
        description: "User information has been successfully updated.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error updating user:', error);
      toast({
        title: "Error updating user",
        description: "There was an error updating the user information.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  const handleAdd = async () => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/register`, newUser);
      setUsers([...users, response.data]);
      onAddClose();
      setNewUser({
        companyName: '',
        contactPerson: '',
        address: '',
        city: '',
        state: '',
        mobileNo: '',
        whatsappNo: '',
        creditLimit: '',
        username: '',
        password: '',
        emailId: '',
      });
      toast({
        title: "Registration successful",
        description: "New user has been successfully registered.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });
      fetchUsers(); // Refresh the user list
    } catch (error) {
      console.error('Error registering user:', error);
      toast({
        title: "Registration failed",
        description: "There was an error registering the new user.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    }
  };

  const openEditModal = (user) => {
    setSelectedUser(user);
    onEditOpen();
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Box overflowX="auto" overflowY="auto" h="80vh">
      <Button colorScheme="blue" mb={4} 
      onClick={() => setActiveComponent('register')}
      
      >
        Add User
      </Button>

      <TableContainer bg="white" p={2}>
        <Table variant="simple" colorScheme="blue" size="sm">
          <Thead >
            <Tr >
              <Th>S. No.</Th>
              <Th>Company Name</Th>
              <Th>Contact Name</Th>
              <Th>Mobile</Th>
              <Th>Email</Th>
              <Th>Password</Th>
              <Th>Type</Th>
              <Th>Credit Limit</Th>
              <Th>Created At</Th>
              {/* <Th>Action</Th> */}
            </Tr>
          </Thead>
          <Tbody>
            {users.length > 0 ? (
              users.map((user, index) => (
                <Tr key={user._id}>
                  <Td>{index + 1}</Td>
                  <Td>{user.companyName}</Td>
                  <Td>{user.contactPerson}</Td>
                  <Td>{user.mobileNo}</Td>
                  <Td>{user.emailId}</Td>
                  <Td>{user.password}</Td>

                  <Td>{user.type}</Td>
                  <Td>{user.creditLimit}</Td>
                  <Td>{formatDate(user.createdAt)}</Td>
                  {/* <Td>
                    <Button size="sm" colorScheme="cyan" onClick={() => openEditModal(user)}>
                      Edit
                    </Button>
                  </Td> */}
                </Tr>
              ))
            ) : (
              <Tr>
                <Td colSpan={9} textAlign="center">
                  No Users Found
                </Td>
              </Tr>
            )}
          </Tbody>
        </Table>
      </TableContainer>

      {/* Edit Modal */}
      <Modal isOpen={isEditOpen} onClose={onEditClose} size="4xl">
  <ModalOverlay  />
  <ModalContent>
    <ModalHeader>Edit User Details</ModalHeader>
    <ModalCloseButton />
    <ModalBody maxHeight="400px" overflowY="auto">
      {selectedUser && (
        <HStack spacing={6} align="start">
          <VStack spacing={4} align="stretch" w="50%" maxHeight="400px" overflowY="auto">
            <FormControl>
              <FormLabel>Company Name</FormLabel>
              <Input
                name="companyName"
                value={selectedUser.companyName || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Contact Person</FormLabel>
              <Input
                name="contactPerson"
                value={selectedUser.contactPerson || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Mobile No.</FormLabel>
              <Input
                name="mobileNo"
                value={selectedUser.mobileNo || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Email ID</FormLabel>
              <Input
                name="emailId"
                value={selectedUser.emailId || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Type</FormLabel>
              <Input
                name="type"
                value={selectedUser.type || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Credit Limit</FormLabel>
              <Input
                name="creditLimit"
                value={selectedUser.creditLimit || ''}
                onChange={handleEditChange}
              />
            </FormControl>
          </VStack>
          <VStack spacing={4} align="stretch" w="50%">
            <FormControl>
              <FormLabel>Address</FormLabel>
              <Input
                name="address"
                value={selectedUser.address || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>City</FormLabel>
              <Input
                name="city"
                value={selectedUser.city || ''}
                onChange={handleEditChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>State</FormLabel>
              <Input
                name="state"
                value={selectedUser.state || ''}
                onChange={handleEditChange}
              />
            </FormControl>
          </VStack>
        </HStack>
      )}
    </ModalBody>
    <ModalFooter>
      <Button colorScheme="blue" onClick={handleEdit}>
        Save
      </Button>
      <Button ml={3} onClick={onEditClose}>
        Cancel
      </Button>
    </ModalFooter>
  </ModalContent>
</Modal>


      {/* Add User Modal */}
      <Modal isOpen={isAddOpen} onClose={onAddClose} size="4xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add New User</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <HStack spacing={4} justify="space-between">
              <VStack spacing={4} align="left" w="50%">
                <FormControl isRequired>
                  <FormLabel>Company Name</FormLabel>
                  <Input
                    name="companyName"
                    value={newUser.companyName}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl isRequired>
                  <FormLabel>Contact Person</FormLabel>
                  <Input
                    name="contactPerson"
                    value={newUser.contactPerson}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl>
                  <FormLabel>Address</FormLabel>
                  <Input
                    name="address"
                    value={newUser.address}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl>
                  <FormLabel>City</FormLabel>
                  <Input
                    name="city"
                    value={newUser.city}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl>
                  <FormLabel>State</FormLabel>
                  <Input
                    name="state"
                    value={newUser.state}
                    onChange={handleAddChange}
                  />
                </FormControl>
              </VStack>
              <VStack spacing={4} align="left" w="50%">
                <FormControl isRequired>
                  <FormLabel>Mobile No</FormLabel>
                  <Input
                    name="mobileNo"
                    value={newUser.mobileNo}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl>
                  <FormLabel>WhatsApp No</FormLabel>
                  <Input
                    name="whatsappNo"
                    value={newUser.whatsappNo}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl isRequired>
                  <FormLabel>Email</FormLabel>
                  <Input
                    name="emailId"
                    type="email"
                    value={newUser.emailId}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl isRequired>
                  <FormLabel>Username</FormLabel>
                  <Input
                    name="username"
                    value={newUser.username}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl isRequired>
                  <FormLabel>Password</FormLabel>
                  <Input
                    name="password"
                    type="password"
                    value={newUser.password}
                    onChange={handleAddChange}
                  />
                </FormControl>
                <FormControl>
                  <FormLabel>Credit Limit</FormLabel>
                  <Input
                    name="creditLimit"
                    type="number"
                    value={newUser.creditLimit}
                    onChange={handleAddChange}
                  />
                </FormControl>
              </VStack>
            </HStack>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={handleAdd}>
              Register
            </Button>
            <Button ml={3} onClick={onAddClose}>
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};

export default UserTable;