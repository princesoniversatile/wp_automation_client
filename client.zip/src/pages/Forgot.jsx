import {
    Button,
    FormControl,
    Flex,
    Heading,
    Input,
    Stack,
    Text,
    useColorModeValue,
    Box,
    Image,
    VStack,
    HStack,
    Icon,
    useToast
  } from '@chakra-ui/react'
  import { useState } from 'react'
  import { Alert, AlertIcon, AlertTitle, AlertDescription, CloseButton } from '@chakra-ui/react'
  import { FaLock, FaEnvelope } from 'react-icons/fa'
  import { Link } from 'react-router-dom'
  import axios from 'axios'
  
  export default function ForgotPasswordForm() {
    const toast = useToast()
      const [email, setEmail] = useState('')
      const [showPasswordPopup, setShowPasswordPopup] = useState(false)
      const [retrievedPassword, setRetrievedPassword] = useState('')
      const [isLoading, setIsLoading] = useState(false)
  
      const handlePasswordRetrieval = async () => {
          setIsLoading(true)
          try {
              const response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/retrievePassword`, { email })
              if (response.data.password) {
                  setRetrievedPassword(response.data.password)
                  setShowPasswordPopup(true)
              } else {
                  throw new Error('Password not found')
              }
          } catch (error) {
              toast({
                title: 'Error',
                description: error.response?.data?.message || 'Failed to retrieve password',
                status: 'error',
                duration: 3000,
                isClosable: true,
                position: 'top'
              })
          } finally {
              setIsLoading(false)
          }
      }
  
      return (
          <Flex
              minH={'100vh'}
              direction={{ base: 'column', md: 'row' }}
              bg={useColorModeValue('gray.100', 'gray.900')}>
              <Box
                  flex={1}
                  bg={useColorModeValue('blue.500', 'blue.900')}
                  color={'white'}
                  p={8}
                  display={{ base: 'none', md: 'flex' }}
                  alignItems={'center'}
                  justifyContent={'center'}>
                  <VStack spacing={8} align={'flex-start'} maxW={'480px'}>
                      <Image src={'https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg'} alt="WhatsApp Logo" boxSize={'100px'} />
                      <Heading size={'2xl'}>WhatsApp Automation Dashboard</Heading>
                      <Text fontSize={'xl'}>
                          Streamline your communication with our powerful WhatsApp automation tools. Reset your password to regain access to your account.
                      </Text>
                  </VStack>
              </Box>
              <Flex
                  flex={1}
                  align={'center'}
                  justify={'center'}
                  bg={useColorModeValue('white', 'gray.800')}>
                  <Stack
                      spacing={8}
                      w={'full'}
                      maxW={'md'}
                      bg={useColorModeValue('white', 'gray.700')}
                      rounded={'xl'}
                      boxShadow={'lg'}
                      p={8}
                      my={12}>
                      <Heading lineHeight={1.1} fontSize={{ base: '2xl', md: '3xl' }}>
                          Forgot your password?
                      </Heading>
                      <Text
                          fontSize={{ base: 'sm', sm: 'md' }}
                          color={useColorModeValue('gray.600', 'gray.400')}>
                          Enter your email address to retrieve your password
                          
                      </Text>
                      <FormControl id="email">
                          <HStack>
                              <Icon as={FaEnvelope} color={'gray.500'} />
                              <Input
                                  placeholder="your-email@example.com"
                                  _placeholder={{ color: 'gray.500' }}
                                  type="email"
                                  size={'lg'}
                                  value={email}
                                  onChange={(e) => setEmail(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      handlePasswordRetrieval()
                                    }
                                  }}
                              />
                          </HStack>
                      </FormControl>
                      <Stack spacing={6}>
                          <Button
                              bg={'blue.400'}
                              color={'white'}
                              _hover={{
                                  bg: 'blue.500',
                              }}
                              size={'lg'}
                              leftIcon={<FaLock />}
                              onClick={handlePasswordRetrieval}
                              isLoading={isLoading}
                              loadingText="Retrieving">
                              Retrieve Password
                          </Button>
                      </Stack>
                      {showPasswordPopup && (
                          <Alert status="success" variant="subtle">
                              <AlertIcon />
                              <Box>
                                  <AlertTitle mr={2}>Password Retrieved</AlertTitle>
                                  <AlertDescription>
                                      Your password is: {retrievedPassword}
                                  </AlertDescription>
                              </Box>
                              <CloseButton position="absolute" right="8px" top="8px" onClick={() => setShowPasswordPopup(false)} />
                          </Alert>
                      )}
                      <Text
                          fontSize={'sm'}
                          color={useColorModeValue('gray.600', 'gray.400')}
                          textAlign={'center'}>
                          Remember your password? <Link to="/login"><Button variant={'link'} color={'blue.400'} style={{ textDecoration: 'none', color: 'blue.400' }}>Log in</Button></Link>
                      </Text>
                  </Stack>
              </Flex>
          </Flex>
      )
  }