import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  CircularProgress,
  Grid,
  GridItem,
  Heading,
  Input,
  Text,
  useToast,
  VStack,
  Progress,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
} from '@chakra-ui/react';
import { RepeatIcon } from '@chakra-ui/icons';
import axios from 'axios';
import { Link } from 'react-router-dom';

const MessageLimit = () => {
  const [messageLimit, setMessageLimit] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [currentLimit, setCurrentLimit] = useState({});
  const [totalLimit, setTotalLimit] = useState(0);
  const [usedLimit, setUsedLimit] = useState(0);
  const [percentageUsed, setPercentageUsed] = useState(0);

  const toast = useToast();

  // Fetch QR Code
  const fetchQrCode = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/qrimage`, {

        responseType: 'blob',
        
      });
      const imageUrl = URL.createObjectURL(response.data);
      setQrCode(imageUrl);
    } catch (error) {
      setError('QR code not available. Please try again later.');
      toast({
        title: 'Failed to load QR code.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  // Check Connection Status
  const checkConnectionStatus = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/check-status`);
      setIsConnected(response.data.connected);
    } catch (error) {
      console.error('Error fetching connection status:', error);
      setIsConnected(false);
      toast({
        title: 'Error fetching connection status.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // Fetch Current Limit
  const fetchCurrentLimit = async () => {
    try {
      const response = await axios.get(`${import.meta.env.VITE_APP_API_URL}/getApiLimit`);
      setCurrentLimit(response.data);
      setTotalLimit(response.data.maxMessagesPerMinute);
      setUsedLimit(response.data.messageCount);
      setPercentageUsed((response.data.messageCount / response.data.maxMessagesPerMinute) * 100);
    } catch (error) {
      console.error('Error fetching current limit:', error);
      toast({
        title: 'Error fetching current limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // Handle Limit Submission
  const handleLimitSubmit = async () => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_APP_API_URL}/setApiLimit`, {
        maxMessagesPerMinute: messageLimit,
      });
      console.log('Message limit set successfully:', response.data);
      toast({
        title: 'Message limit set successfully!',
        status: 'success',
        duration: 3000,
        isClosable: true,
      });
    } catch (error) {
      console.error('Error setting message limit:', error);
      toast({
        title: 'Failed to set message limit.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // Initialize Data
  useEffect(() => {
    const initialize = async () => {
      await fetchQrCode();
      await checkConnectionStatus();
      await fetchCurrentLimit();
    };
    initialize();
  }, []);

  useEffect(() => {
    const initialize = async () => {
      await fetchCurrentLimit();
  };
  initialize();
  }, [handleLimitSubmit]);

  // Handle Refresh
  const handleRefresh = () => {
    setMessageLimit('');
    fetchQrCode();
    checkConnectionStatus();
    fetchCurrentLimit();
  };

  // Handle Limit Change
  const handleLimitChange = (event) => {
    setMessageLimit(event.target.value);
  };

  // Remaining Limit Calculation
  const remainingLimit = currentLimit.maxMessagesPerMinute - currentLimit.messageCount;

  return (
    <Box
      p={6}
    //   maxWidth="1200px"
    //   margin="auto"
      display="flex"
      flexDirection="column"
      alignItems="center"
      bg="gray.50"
      borderRadius="lg"
      boxShadow="lg"
    >
      <Heading as="h1" size="lg" mb={6} textAlign="center">
        Message Limit Dashboard
      </Heading>

      <Button
        leftIcon={<RepeatIcon />}
        colorScheme="blue"
        onClick={handleRefresh}
        width="full"
        mb={6}
      >
        Refresh Data
      </Button>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
        <GridItem>
          <Box
            bg="white"
            p={5}
            borderRadius="md"
            boxShadow="md"
            textAlign="center"
          >
            <Heading as="h5" size="md" mb={4}>
              Configure Message Limit
            </Heading>
            <Input
              placeholder="Message Limit"
              value={messageLimit}
              type="number"
              onChange={handleLimitChange}
              mb={4}
            />
            <Button colorScheme="blue" onClick={handleLimitSubmit} width="full">
              Set Limit
            </Button>
          </Box>
        </GridItem>

        <GridItem>
          <Box bg="white" p={4} borderRadius="md" boxShadow="md">
            <Heading as="h6" size="sm" mb={4} textAlign="center">
              Usage Overview
            </Heading>
            <Progress
              value={percentageUsed}
              size="lg"
              colorScheme={percentageUsed > 80 ? "red" : "green"}
              borderRadius="full"
              mb={4}
            />
            <VStack spacing={4} align="stretch">
              <Stat>
                <StatLabel>Total Limit</StatLabel>
                <StatNumber>{totalLimit}</StatNumber>
                <StatHelpText>Total available messages</StatHelpText>
              </Stat>
              <Stat>
                <StatLabel>Used</StatLabel>
                <StatNumber>{usedLimit}</StatNumber>
                <StatHelpText>Messages sent</StatHelpText>
              </Stat>
              <Stat>
                <StatLabel>Remaining</StatLabel>
                <StatNumber>{remainingLimit}</StatNumber>
                <StatHelpText>Messages available</StatHelpText>
              </Stat>
            </VStack>
          </Box>
        </GridItem>
      </Grid>

      {loading && (
        <CircularProgress isIndeterminate color="blue.300" mt={6} />
      )}

      {error && (
        <Text color="red.500" mt={4}>{error}</Text>
      )}

    <Box display={{ base: 'none', md: 'block' }} position="fixed" top="50%" right="10%" zIndex="1">
      <VStack spacing={4}>
            <Button colorScheme="blue" size="md" as={Link} to="/dashboard">Dashboard</Button>
            <Button colorScheme="blue" size="md" as={Link} to="/settings">Settings</Button>
            <Button colorScheme="blue" size="md" as={Link} to="/help">Help</Button>
      </VStack>
    </Box>
    </Box>
  );
};

export default MessageLimit;